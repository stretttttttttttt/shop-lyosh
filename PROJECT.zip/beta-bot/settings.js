global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['629xxxx']
global.botname = 'Beta Bot'
global.thumb = "https://telegra.ph/file/003370ca4052886c0bd5c.jpg"
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "Lyosh Only"
global.sticker2 = "❕"

// setting push kontak
global.pushviddeo = 'https://telegra.ph/file/2d25eb0db37e8e88fdef6.mp4' //video
global.pushphoto = 'https://telegra.ph/file/8e8d0d6566764b6b9ce7e.jpg'
global.waktu = 9000 // sama dengan 9 detik

// setting Panel
global.domain = 'https://server.domain.my.id'
global.apikey = 'ptla_sCNxln6k2'
global.c_apikey = 'ptlc_afI38of4'
global.eggs = '15'
global.loca = '1'